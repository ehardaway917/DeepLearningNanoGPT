"""Generate nanogpt_experiments.ipynb from nanogpt_experiments.py.

nanogpt_experiments.py is the single source of truth. It is split into cells at the
"# %%" markers: "# %% [markdown]" starts a markdown cell (its comment lines
lose their leading "# "), a bare "# %%" starts a code cell.

    python build_notebook.py
"""
import json

SOURCE, TARGET = "nanogpt_experiments.py", "nanogpt_experiments.ipynb"


def build_cells(text):
    cells, kind, lines = [], None, []

    def flush():
        while lines and not lines[-1].strip():
            lines.pop()
        if kind is None or not lines:
            return
        if kind == "markdown":
            body = [line[2:] if line.startswith("# ") else line.lstrip("#") for line in lines]
        else:
            body = lines
        cell = {"cell_type": kind, "metadata": {},
                "source": [line + "\n" for line in body[:-1]] + [body[-1]]}
        if kind == "code":
            cell.update({"execution_count": None, "outputs": []})
        cell["id"] = f"cell-{len(cells)}"
        cells.append(cell)

    for line in text.splitlines():
        if line.startswith("# %%"):
            flush()
            kind, lines = ("markdown" if "[markdown]" in line else "code"), []
        else:
            lines.append(line)
    flush()
    return cells


def main():
    with open(SOURCE, encoding="utf-8") as f:
        cells = build_cells(f.read())
    notebook = {
        "cells": cells,
        "metadata": {
            "accelerator": "GPU",
            "colab": {"provenance": []},
            "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
            "language_info": {"name": "python"},
        },
        "nbformat": 4,
        "nbformat_minor": 5,
    }
    with open(TARGET, "w", encoding="utf-8") as f:
        json.dump(notebook, f, indent=1)
    print(f"Wrote {TARGET}: {len(cells)} cells")


if __name__ == "__main__":
    main()
