"""Convert report.md into nanoGPT_report.docx with every figure embedded.

Handles the Markdown that report.md uses: headings, paragraphs with **bold**,
*italic* and `code`, bullet and numbered lists, pipe tables, fenced code
blocks, ![caption](image.png){width} figures (width in inches, optional) and
\pagebreak lines.

    python build_report.py
"""
import re

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.shared import Inches, Pt, RGBColor

SOURCE, TARGET = "report.md", "nanoGPT_report.docx"
INLINE = re.compile(r"(\*\*[^*]+\*\*|`[^`]+`|\*[^*]+\*)")


def add_runs(paragraph, text):
    for part in INLINE.split(text):
        if not part:
            continue
        if part.startswith("**"):
            paragraph.add_run(part[2:-2]).bold = True
        elif part.startswith("`"):
            run = paragraph.add_run(part[1:-1])
            run.font.name = "Consolas"
            run.font.size = Pt(9.5)
        elif part.startswith("*"):
            paragraph.add_run(part[1:-1]).italic = True
        else:
            paragraph.add_run(part)


def add_table(doc, rows):
    cells = [[c.strip() for c in r.strip().strip("|").split("|")] for r in rows]
    header, body = cells[0], cells[2:]
    table = doc.add_table(rows=1 + len(body), cols=len(header))
    table.style = "Light Grid Accent 1"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, row in enumerate([header] + body):
        for j, text in enumerate(row):
            p = table.rows[i].cells[j].paragraphs[0]
            add_runs(p, text)
            for run in p.runs:
                run.font.size = Pt(8.5)
                if i == 0:
                    run.bold = True
    doc.add_paragraph()


def main():
    doc = Document()
    style = doc.styles["Normal"]
    style.font.name = "Calibri"
    style.font.size = Pt(10)
    style.paragraph_format.space_after = Pt(3)
    for section in doc.sections:
        section.left_margin = section.right_margin = Inches(0.7)
        section.top_margin = section.bottom_margin = Inches(0.6)

    lines = open(SOURCE, encoding="utf-8").read().splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line.strip():
            i += 1
        elif line.startswith("```"):
            j = i + 1
            while not lines[j].startswith("```"):
                j += 1
            p = doc.add_paragraph()
            run = p.add_run("\n".join(lines[i + 1:j]))
            run.font.name = "Consolas"
            run.font.size = Pt(9.5)
            i = j + 1
        elif line.startswith("#"):
            level = len(line) - len(line.lstrip("#"))
            doc.add_heading(line.lstrip("#").strip(), level=level - 1 if level > 1 else 0)
            i += 1
        elif line.strip() == r"\pagebreak":
            doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)
            i += 1
        elif line.startswith("!["):
            caption, path, width = re.match(r"!\[(.*)\]\(([^)]*)\)(?:\{([\d.]+)\})?", line).groups()
            doc.add_picture(path, width=Inches(float(width or 6.8)))
            doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            add_runs(p, caption)
            for run in p.runs:
                run.italic = True
                run.font.size = Pt(9.5)
                run.font.color.rgb = RGBColor(0x44, 0x44, 0x44)
            i += 1
        elif line.startswith("|"):
            j = i
            while j < len(lines) and lines[j].startswith("|"):
                j += 1
            add_table(doc, lines[i:j])
            i = j
        elif re.match(r"^(\s*)(- |\d+\. )", line):
            indent, marker = re.match(r"^(\s*)(- |\d+\. )", line).groups()
            style = "List Bullet" if marker == "- " else "List Number"
            if indent:
                style += " 2"
            text = line[len(indent) + len(marker):]
            i += 1
            while i < len(lines) and lines[i].startswith("  ") and not re.match(r"^\s*(- |\d+\. )", lines[i]):
                text += " " + lines[i].strip()
                i += 1
            add_runs(doc.add_paragraph(style=style), text)
        else:
            text = line
            i += 1
            while i < len(lines) and lines[i].strip() and not re.match(r"^(#|!\[|\||```|\s*- |\d+\. )", lines[i]):
                text += " " + lines[i].strip()
                i += 1
            add_runs(doc.add_paragraph(), text)

    doc.save(TARGET)
    print(f"Wrote {TARGET}")


if __name__ == "__main__":
    main()
