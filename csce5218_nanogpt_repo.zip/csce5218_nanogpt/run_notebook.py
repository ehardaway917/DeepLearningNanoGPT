﻿"""Execute nanogpt_experiments.ipynb top to bottom and save the outputs into it.

The notebook runs in this folder and writes figures/, runs/<name>/eval.json and
results.json here; report.md is written from that run, so the report and the
notebook show the same numbers.

    python run_notebook.py
"""
import time

import nbformat
from nbclient import NotebookClient

NOTEBOOK = "nanogpt_experiments.ipynb"
WORKDIR = "."

nb = nbformat.read(NOTEBOOK, as_version=4)
start = time.time()
NotebookClient(nb, timeout=None, kernel_name="python3",
               resources={"metadata": {"path": WORKDIR}}).execute()
nbformat.write(nb, NOTEBOOK)
print(f"Executed {NOTEBOOK} in {time.time() - start:.0f}s")
