# nanoGPT: code analysis and a 128-run hyperparameter study

**CSCE 5218 Deep Learning (Amir Mirzaeinia), nanoGPT assignment.** Team: [names]. Code, configs, logs and the executed notebook: [GitHub repository URL].

**Summary.** We answered the 17 study questions on `model.py`, `train.py` and `sample.py` (Section 2). We then trained nanoGPT on character-level Tiny Shakespeare for **all 2^7 = 128 combinations** of block_size, n_layer, n_head, n_embd, batch_size, max_iters and dropout, plus 8 seed repeats to measure noise. The main findings:

- **Width, training length and batch size dominate.** Their main effects on validation loss are −0.221 (n_embd 128 → 256), −0.195 (1000 → 2000 iterations) and −0.130 (batch 8 → 16). Dropout 0.2 is *worse* than 0.1 (+0.083), because no model is trained long enough to overfit.
- **Depth and block size matter little, heads not at all.** Depth gains −0.014, block size −0.034, and heads +0.000. Seed noise gives a main-effect standard error of 0.0017.
- **At equal tokens, steps win.** More optimizer steps beat bigger batches, and bigger batches beat longer context windows, in every one of 32 matched pairs. The block_size gain mostly comes from extra tokens per step.
- **Best model.** It is in our slice [128, 6]: n_embd 256, 8 heads, batch 16, 2000 iterations, dropout 0.1. It reaches validation loss **1.652** (perplexity 5.2) in 20 s. A 4-layer model is statistically tied with it at 25% less time.
- **Text quality follows validation loss.** The share of real words in generated text correlates −0.96 with validation loss. Even the best model writes plausible Shakespeare *form* (speaker tags, verse lines, real names) without meaning across lines.

## 1. Introduction: the nanoGPT architecture

nanoGPT is a compact re-implementation of GPT-2 in PyTorch. It is a **decoder-only transformer**: a stack of identical blocks of causal self-attention plus an MLP, trained to predict the next token from the tokens before it. On Tiny Shakespeare we use the character-level setup, where each of the 65 distinct characters is one token. The model has these parts (`model.py`):

- **Embeddings.** A token embedding `wte` (65 × n_embd) and a learned position embedding `wpe` (block_size × n_embd) are summed, then passed through dropout.
- **Blocks.** There are `n_layer` pre-norm transformer blocks. Each one applies LayerNorm, multi-head causal self-attention with `n_head` heads, and a residual add, then LayerNorm, an MLP (n_embd → 4·n_embd → n_embd, GELU) and a second residual add.
- **Output.** A final LayerNorm `ln_f` feeds a linear `lm_head` back to 65 logits. Its weight is **tied** to `wte`.

Without biases (`bias=False` in our runs), each block has 12·n_embd² + 2·n_embd parameters. The full model therefore has about 12·n_layer·n_embd² + (65 + block_size + 1)·n_embd parameters. That gives 0.80M parameters for the smallest grid model (4 layers, n_embd 128, block 64) and 4.77M for the largest (6 layers, n_embd 256, block 128). Training (`train.py`) minimizes next-character cross-entropy with AdamW, using a warmup-plus-cosine learning-rate schedule. Generation (`sample.py`) samples one character at a time from the model's softmax, using a temperature and an optional top-k cut-off.

## 2. Code analysis: answers to the study questions

Line numbers refer to the unmodified files at commit `3adf61e`.

### 2.1 model.py

**Q1. How is the causal self-attention mask implemented?** There are two code paths, and both stop position t from attending to any position after t.

- **Flash path.** On PyTorch ≥ 2.0 (our case) the model calls `F.scaled_dot_product_attention(q, k, v, ..., is_causal=True)` (line 64). The fused kernel applies the lower-triangular mask itself.
- **Fallback path.** On older PyTorch, `__init__` registers a buffer `bias = torch.tril(torch.ones(block_size, block_size))` reshaped to (1, 1, T, T) (lines 49–50). The forward pass computes `att = q @ kᵀ / √head_size`, then sets every entry above the diagonal to −∞ with `att.masked_fill(self.bias[:,:,:T,:T] == 0, float('-inf'))` (line 68). The softmax turns those entries into exact zeros.

The mask is a buffer, not a parameter: it is never trained, and it is sliced to the current sequence length T.

**Q2. What is the purpose of LayerNorm and where is it positioned?** LayerNorm rescales each token's n_embd-dimensional vector to zero mean and unit variance across its features. It then applies a learned per-feature scale, plus a shift only when `bias=True`; eps is 1e-5. nanoGPT defines its own `LayerNorm` class (lines 18–27) because PyTorch's version could not switch off the bias. The model is **pre-norm**:

- `ln_1` is applied before attention and `ln_2` before the MLP, *inside* each residual branch (`x = x + attn(ln_1(x))`, lines 104–105).
- A final `ln_f` sits after the last block and before `lm_head` (line 182).

Normalizing the branch inputs while leaving the residual stream untouched keeps activations and gradients well scaled through deep stacks, which makes training stable.

**Q3. Explain the forward pass through one transformer block.** The input x has shape (B, T, C).

1. `h = ln_1(x)`.
2. `c_attn` projects h to 3C features, which are split into q, k and v (line 56).
3. Each of q, k and v is reshaped into n_head heads of size C/n_head: (B, nh, T, hs) (lines 57–59).
4. Causal scaled dot-product attention runs per head: softmax(q kᵀ/√hs) v, masked to positions ≤ t.
5. The heads are concatenated back to (B, T, C) (line 72), then go through the output projection `c_proj` and residual dropout (line 75).
6. The result is added to x: `x = x + attn(...)`.
7. `h = ln_2(x)` goes through the MLP: `c_fc` (C → 4C), GELU, `c_proj` (4C → C) and dropout (lines 87–92).
8. That is added to x again. The output keeps the shape (B, T, C).

**Q4. How are positional embeddings handled?** They are **learned absolute** embeddings, `wpe = nn.Embedding(block_size, n_embd)` (line 128), not sinusoidal ones. In `forward`, `pos = torch.arange(0, t)` (line 174) looks up one vector per position, which is added to the token embeddings: `x = drop(tok_emb + pos_emb)` (line 179). Because the table has only block_size rows, the model cannot process sequences longer than block_size (assert on line 173). `get_num_params` leaves `wpe` out of the reported count (lines 150–160), and `crop_block_size` shrinks the table (line 201).

**Q5. What is the role of n_embd, n_head and n_layer?**

- **n_embd** (C) is the width of the residual stream: the size of every token vector and of every embedding. Parameters grow with C².
- **n_head** splits C into heads of size C/n_head, which attend independently and in parallel (the assert on line 33 requires divisibility). It changes *how* attention capacity is divided, not the parameter count.
- **n_layer** is the number of stacked blocks, or depth. Parameters and compute grow linearly with it. It also scales the initialization of the residual projections, std 0.02/√(2·n_layer) (lines 143–145), so the residual stream does not grow with depth.

**Q6. How does dropout regularization work in the architecture?** One rate, `config.dropout`, is applied at four places:

- the embeddings, after summing token and position embeddings (line 179);
- the attention probabilities (`dropout_p` of the flash kernel on line 64, or `attn_dropout` on line 70);
- the attention output after `c_proj`, as residual dropout (line 75);
- the MLP output (line 91).

During training each activation is zeroed with probability p and the survivors are scaled by 1/(1−p). Dropout is active only in `model.train()` mode. `estimate_loss` (line 218) and `sample.py` (line 51) call `model.eval()`, which turns it off, and the flash path passes `dropout_p = 0` when not training.

### 2.2 train.py

**Q1. How is the learning-rate schedule implemented?** By `get_lr(it)` (lines 231–242), which is evaluated every iteration and written into every optimizer parameter group (lines 258–260). It has three phases:

1. **Linear warmup** for `warmup_iters` steps, from learning_rate/(warmup+1) up to learning_rate.
2. **Cosine decay** from learning_rate to `min_lr` between warmup_iters and lr_decay_iters: `min_lr + 0.5·(1 + cos(π·ratio))·(lr − min_lr)`.
3. **Constant `min_lr`** after lr_decay_iters.

With the Shakespeare config this means 1e-3 → 1e-4 over 100 warmup steps (Fig. 1, Section 3). Setting `decay_lr=False` keeps the rate constant.

**Q2. Explain the gradient accumulation strategy.** One optimizer step runs `gradient_accumulation_steps` micro-batches (line 292). Each micro-batch loss is divided by the number of steps (line 301) before `backward()`, so the gradients that accumulate in `.grad` average to the gradient of one large batch. Then:

- the gradient norm is clipped to 1.0 (after `scaler.unscale_`);
- the optimizer steps once and the gradients are cleared (lines 306–314).

The effective batch is accumulation steps × batch_size × number of GPUs, printed as tokens per iteration (line 101). Under DDP, the accumulation steps are split across GPUs (line 95) and gradients are synchronized only on the last micro-step (line 298). The next batch is prefetched during the forward pass (line 303). The Shakespeare config uses 1 step (no accumulation); the GPT-2 default is 40.

**Q3. How are training and validation splits created?** Not in train.py, but in `data/shakespeare_char/prepare.py`. That script takes the **first 90%** of the text as train and the **last 10%** as validation, contiguous and unshuffled (lines 38–40). It encodes both to uint16 ids and writes `train.bin` and `val.bin`. `get_batch(split)` (lines 116–131) opens the matching file as an `np.memmap`: a NumPy array backed by the file on disk, which the operating system pages in on demand instead of loading it all into RAM. The memmap is re-created on every call to avoid a known memory leak (comment on lines 117–118). The split is by position in the text, so validation is a later passage of the plays and not random characters.

**Q4. What loss function is used and why?** Cross-entropy over the vocabulary, averaged over every position of every sequence: `F.cross_entropy(logits.view(-1, V), targets.view(-1), ignore_index=-1)` (model.py line 187). Next-token prediction is a V-way classification at each position, and minimizing cross-entropy is maximum-likelihood training of the model's next-character distribution. The value is the average negative log-likelihood in nats: exp(loss) is the perplexity, and a uniform guess scores ln 65 = 4.17 (the step-0 loss in every log). `ignore_index=-1` lets padding targets be masked out.

**Q5. How does block_size affect batch construction?** `get_batch` draws `batch_size` random start offsets i in [0, len − block_size) (line 123). It slices `x = data[i : i+block_size]` and the same window shifted by one, `y = data[i+1 : i+1+block_size]` (lines 124–125). Each window therefore yields block_size training targets, whose contexts range from 1 to block_size characters, and an iteration processes batch_size × block_size tokens. A larger block_size has four consequences:

- more tokens and gradient signal per step;
- longer contexts for the model to learn from;
- a larger `wpe` table;
- an attention cost that grows with block_size², in both compute and activation memory.

**Q6. What is the purpose of max_iters and lr_decay_iters?** `max_iters` is the training budget. The loop stops `if iter_num > max_iters` (line 332), so it actually runs max_iters + 1 updates, and the last evaluation happens at iteration max_iters. `lr_decay_iters` is the length of the cosine decay, after which the learning rate stays at min_lr. The comment on line 67 says to keep it close to max_iters, so the learning rate reaches min_lr exactly when training ends. If it is longer, training stops while the learning rate is still high. If it is shorter, the last steps run at min_lr. We set lr_decay_iters = max_iters in every run (Fig. 1, Section 3).

### 2.3 sample.py

**Q1. How does temperature affect the sampling distribution?** The logits of the last position are divided by `temperature` before the softmax (model.py line 318). A temperature below 1 sharpens the distribution toward the most likely characters (it approaches greedy argmax as T → 0). A temperature above 1 flattens it toward uniform: more varied text, but more mistakes. The default is 0.8 (sample.py line 17).

**Q2. What is top-k sampling and how does it work?** Only the k largest logits are kept: `torch.topk` finds the k-th largest value, every smaller logit is set to −∞, and the softmax then renormalizes over the remaining k tokens (model.py lines 320–322). This removes the long tail of unlikely tokens, which at low temperature produce occasional garbage. The default `top_k = 200` is larger than our 65-character vocabulary, and `min(top_k, vocab)` caps it, so for this model the default changes nothing.

**Q3. How is the context window managed during generation?** `generate` loops over max_new_tokens. Each step crops the running sequence to its last block_size tokens, `idx[:, -block_size:]` (model.py line 314), because the position table only covers block_size positions. It runs a full forward pass on that window and appends the sampled token. Anything older than block_size characters is forgotten. There is no KV cache, so every step recomputes the whole window. At inference `forward` applies `lm_head` only to the last position (line 190).

**Q4. Why might you want to use different sampling strategies?** Generation trades **fidelity** against **diversity**:

- Greedy or low-temperature decoding is safe but repetitive, and often loops.
- High temperature gives novel text but more misspellings and nonsense.
- Top-k (or top-p) cuts the tail of the distribution without flattening its head.

The right setting depends on the task (exact completion vs creative writing) and on the model: a weak model needs a lower temperature or top-k to stay legible, and a strong one can sample more freely. Different seeds and strategies are also a way to inspect what the model has learned.

**Q5. How does the model handle the start of generation?** The prompt `start` (default `"\n"`, line 14; `FILE:prompt.txt` reads it from a file) is encoded into a (1, t) tensor of ids (lines 77–81). It uses the `stoi` table in `meta.pkl` when the checkpoint's `config['dataset']` points to one (lines 57–68), and GPT-2 BPE through `tiktoken` otherwise. The seed is set (lines 26–27), the model is switched to `eval()` mode, and `generate` extends the prompt one token at a time. The model always needs at least one context token. For Shakespeare, "\n" is a natural start because speeches begin after a newline.

A pitfall we hit: the checkpoint-saving snippet from the assignment slides stores no `config`. With such a checkpoint, `sample.py` cannot find `meta.pkl` and silently decodes the character ids as GPT-2 BPE tokens, which prints nonsense. Our version of the snippet also saves `config` (Section 3). On PyTorch ≥ 2.6, `torch.load` defaults to `weights_only=True`, which the template notebook works around with a commented-out `sed` fix.

## 3. Experimental setup

**Dataset.** Tiny Shakespeare at the character level: 1,115,394 characters, a 65-symbol vocabulary, the first 90% for training (1,003,854 tokens) and the last 10% for validation (111,540 tokens), prepared with nanoGPT's `prepare.py`. A uniform guess scores ln 65 = 4.17.

**Design: a full 2^7 factorial.** We ran every combination of the seven factors on the slide, 128 runs in total:

| Factor | Low | High |
|---|---|---|
| block_size | 64 | 128 |
| n_layer | 4 | 6 |
| n_head | 4 | 8 |
| n_embd | 128 | 256 |
| batch_size | 8 | 16 |
| max_iters | 1000 | 2000 |
| dropout | 0.1 | 0.2 |

Each of the 128 runs is one point. Because the design is complete, every factor's **main effect**, meaning the mean at its high level minus the mean at its low level, averages over all 64 combinations of the other six factors. Every **two-factor interaction** can be estimated the same way, with no confounding.

**Slices.** The slides split the grid by (block_size, n_layer) into four slices of 32 runs: [64, 4], [64, 6], [128, 4] and [128, 6]. Our group divided them as follows: [names] took [64, 4] and [64, 6], [name] took [128, 4], and [name] took [128, 6]. To protect the report against a missing or inconsistent slice, we also ran all 128 configurations in one pipeline (same code, same machine, same seeds), so every number below is directly comparable. Appendix A lists each slice separately.

**Fixed settings.** Everything outside the grid comes from nanoGPT's `config/train_shakespeare_char.py`:

- AdamW (β₂ = 0.99, weight decay 0.1), gradient clip 1.0, no bias terms, gradient accumulation 1;
- learning rate 1e-3, 100 warmup iterations, cosine decay to 1e-4;
- bf16 autocast, `compile=False`.

We set `lr_decay_iters = max_iters` so that both training lengths finish their cosine decay (Fig. 1). With the template's fixed `lr_decay_iters=2000`, the 1000-iteration runs would stop with the learning rate still at about 5.9e-4, and the max_iters effect would be mixed up with an unfinished schedule. Training losses were logged every 100 iterations on 40 batches per split (`eval_interval=100`, `eval_iters=40`).

![Figure 1. The learning-rate schedule (train.py get_lr) for the two max_iters settings, with lr_decay_iters = max_iters.](figures/fig_lr_schedule.png){4.6}

**Code changes.** We changed only `train.py`, and only in three places. It now accepts `--seed`. It records wall-clock time and peak GPU memory for the training loop. At the end, it saves the final model using the slides' checkpoint snippet, extended to save `config` as well (Section 2.3, Q5), and prints a one-line JSON summary. `train_py.patch` in the repository holds the full diff.

**Measurements.**

- **Losses.** `train.py`'s logged losses come from random batches. Even the most precise of them used only about 20–80k tokens, too noisy to rank 128 runs. So we re-measured every final model **exactly** in float32:
  - validation loss over the whole validation split, in non-overlapping block_size windows;
  - training loss on the same number of windows at fixed random offsets in the training split;
  - their difference, the **gap**, as the overfitting indicator.
  The exact validation loss correlates 0.999 with train.py's last estimate.
- **Cost.** Training wall-clock time, median step time, peak GPU memory (`torch.cuda.max_memory_allocated`) and the parameter count.
- **Text.** A 500-character sample per model with `sample.py`'s settings (prompt "\n", seed 1337, temperature 0.8, top-k 200). From each sample we compute the **valid-word rate**: the share of generated words that occur in the training text.
- **Context use.** The validation loss at each position in the window, as a proxy for long-range dependencies.

**Seeds and noise.** All grid runs use nanoGPT's seed 1337. Four configs spread across the grid were rerun with seeds 1338 and 1339. Their pooled standard deviation is **σ = 0.0096** for validation loss and 0.003 for the gap. A main effect averages 64 runs against 64, so its standard error is 2σ/√128 = **0.0017**. Differences between two *individual* runs smaller than about 0.03 (≈ 2√2·σ) are noise.

**Hardware.** RTX 5090, PyTorch 2.7.1 + CUDA 12.8, one run at a time. The 128 grid runs took 27.5 minutes of training time in total, between 7 and 21 s per run.

**Timing incident.** The first ~30 runs, all in our [128, 6] slice, overlapped with a GPU-heavy video game on the same machine and ran 1.1–6.5× slower (median 3.2×). We reran all 32 runs of that slice with the same seeds on an idle machine and kept the first-pass logs in `runs_slow_archive/`. As a side effect this gave 32 same-seed reproducibility checks: the final logged validation estimates were identical in 23 of 32 runs, differed by at most 0.0007 in 8, and by 0.01 in one, consistent with non-deterministic GPU kernels.

## 4. Results

### 4.1 Overview

| Slice (member) | Best val loss | Median | Worst | Best config (heads, embd, batch, iters, dropout) | Slice training time |
|---|---|---|---|---|---|
| [64, 4] (member 1) | 1.757 | 2.045 | 2.334 | 8, 256, 16, 2000, 0.1 | 5.7 min |
| [64, 6] (member 2) | 1.758 | 2.041 | 2.307 | 4, 256, 16, 2000, 0.1 | 7.7 min |
| [128, 4] (member 3) | 1.654 | 2.027 | 2.350 | 4, 256, 16, 2000, 0.1 | 6.3 min |
| **[128, 6] (member 4, ours)** | **1.652** | 2.010 | 2.285 | 8, 256, 16, 2000, 0.1 | 7.8 min |

The validation loss ranges from **1.652 to 2.350** over the grid. The best model, `b128_l6_h8_e256_bs16_it2000_d0.1` from our slice, reaches a validation loss of 1.652 (perplexity 5.2) and a training loss of 1.467. It has 4.77M parameters, trained in 20.4 s and peaked at 209 MB of GPU memory. Its lead over the next three runs (1.654, 1.655, 1.664) is within seed noise. All four share **n_embd 256, batch 16, 2000 iterations, dropout 0.1 and block 128**, and differ only in layers and heads. In each slice, the best run is the one with the largest width, batch and iteration count and the lower dropout. The worst runs are all n_embd 128, batch 8, 1000 iterations, dropout 0.2. Every curve is still falling at the end of training (Fig. 2). Validation loss turned upward over the last few hundred iterations in only 6 runs, all with n_embd 256 and 2000 iterations: the start of overfitting.

![Figure 2. Validation loss curves (train.py estimates) of all 32 runs in each slice. Best (blue) and worst (orange) are highlighted; dashed lines show their training loss.](figures/fig_curves_by_slice.png)

### 4.2 Which hyperparameters matter

| Factor (low → high) | Δ val loss | in SE | Δ gap | Δ time (s) | Δ peak memory (MB) | Δ valid-word rate |
|---|---|---|---|---|---|---|
| n_embd 128 → 256 | **−0.221** | −130 | +0.074 | +0.3 | +70 | +23 pts |
| max_iters 1000 → 2000 | **−0.195** | −115 | +0.060 | +8.0 | 0 | +19 pts |
| batch_size 8 → 16 | **−0.130** | −77 | +0.040 | +0.4 | +31 | +12 pts |
| dropout 0.1 → 0.2 | **+0.083** | +49 | −0.024 | −0.1 | 0 | −5 pts |
| block_size 64 → 128 | −0.034 | −20 | +0.015 | +0.7 | +31 | +3 pts |
| n_layer 4 → 6 | −0.014 | −8 | 0.000 | +3.2 | +30 | 0 pts |
| n_head 4 → 8 | +0.000 | +0.2 | −0.001 | −0.2 | 0 | −1 pt |

![Figure 3. Main effects over the 128 runs (high level minus low level). The gray band in the first panel is ±2 SE of seed noise.](figures/fig_main_effects.png)

Six of the seven factors have effects far beyond seed noise (Fig. 3). Only **n_head has no effect at all**: +0.0003, 0.2 SE.

- **Width, training length and batch size dominate.** Doubling n_embd lowers validation loss by 0.22 on average, doubling max_iters by 0.20 and doubling the batch by 0.13. Together they explain most of the 0.7 spread between the best and worst run.
- **Dropout 0.2 is worse than 0.1 by 0.083.** It narrows the train/val gap by 0.024, but it costs more in fit than it saves in generalization, because these models are not yet overfitting (Section 4.4).
- **Block size and depth help a little.** block_size 128 gains 0.034 and 6 layers gain 0.014.

![Figure 4. Mean validation curve at each level of each factor (first 1,000 iterations; all 2,000 for max_iters). Width and batch size separate early; dropout and block size later; layers and heads hardly at all. The 1000- and 2000-iteration runs follow nearly the same curve up to iteration 1000.](figures/fig_curves_by_factor.png)

**Interactions** (Fig. 5). The largest ones are 5–16 SE, but at most 0.027 in size, smaller than every main effect except layers and heads. Three of them change how a factor should be read:

- **block_size × max_iters (−0.027).** The longer block helps much more with longer training: −0.060 at 2,000 iterations against −0.007 at 1,000.
- **n_layer × n_embd (+0.021).** Depth helps narrow models (−0.034 at n_embd 128) and slightly hurts wide ones (+0.007 at n_embd 256). At a fixed iteration budget, a 6-layer, 256-wide model has more parameters to fit than it can train.
- **n_head × n_embd (+0.012).** Eight heads help slightly at width 128 (−0.012) and hurt slightly at width 256 (+0.012). That is why the main effect of heads cancels to zero.

![Figure 5. Two-factor interaction effects on validation loss. The SE of one cell is 0.0017.](figures/fig_interactions.png){4.4}

### 4.3 Cost: parameters, memory and time

| n_layer | n_embd | block | Parameters | Peak MB (batch 8) | Peak MB (batch 16) | Median step (ms) |
|---|---|---|---|---|---|---|
| 4 | 128 | 64 | 0.80M | 38 | 49 | 4.6 |
| 4 | 128 | 128 | 0.81M | 49 | 72 | 5.1 |
| 4 | 256 | 64 | 3.18M | 80 | 103 | 4.6 |
| 4 | 256 | 128 | 3.20M | 103 | 146 | 5.3 |
| 6 | 128 | 64 | 1.20M | 48 | 64 | 6.2 |
| 6 | 128 | 128 | 1.21M | 64 | 97 | 7.1 |
| 6 | 256 | 64 | 4.75M | 111 | 143 | 6.1 |
| 6 | 256 | 128 | 4.77M | 143 | 209 | 7.1 |

- **Parameters** follow 12·n_layer·n_embd². Width quadruples the count; depth multiplies it by 1.5. Block size 128 adds only 64 more rows to the position table (8k or 16k parameters), and n_head adds nothing.
- **Memory** is small for every model, at most 209 MB. It grows with width, batch, block and depth, but not with heads, iterations or dropout.
- **Time is not driven by model size.** Doubling n_embd quadruples the parameters yet adds only 0.3 s per run. A step takes 4.6 ms at 4 layers and 6.2–7.1 ms at 6 layers, whatever the width or batch. Models this small leave the GPU mostly idle: each step costs a fixed per-layer overhead of Python and kernel launches, not arithmetic. So wall-clock time tracks **iterations × layers**: max_iters adds 8.0 s and n_layer 3.2 s, and nothing else matters. The median step time predicts total time with correlation 0.99.

Because of this, the cheapest way to lower the loss is to add width and batch, which are almost free in time. The fastest near-best model is `b128_l4_h4_e256_bs16_it2000_d0.1`: validation loss 1.654, 15.3 s. It is within noise of the best run (1.652, 20.4 s) at 25% less time (Fig. 6, left).

![Figure 6. Validation loss against training time (left, with the best-so-far frontier), tokens processed (middle) and parameters (right).](figures/fig_cost.png)

### 4.4 Overfitting: the train/validation gap

Every final model is close to the diagonal (Fig. 7). The gap ranges from −0.005 to 0.185, with a median of 0.063. It grows with everything that helps the fit: width +0.074, iterations +0.060, batch +0.040, block +0.015. It shrinks only with dropout (−0.024). The best model also has the largest gap (0.185). Across the grid, **lower validation loss goes with a larger gap**: no run has trained long enough for the growing gap to cancel the gain in fit. For the eight strongest configs (n_embd 256, batch 16, 2000 iterations), dropout 0.2 lowers the gap from 0.171 to 0.159 but raises validation loss from 1.708 to 1.790. In this budget regime the models are still **under-fitted**, so stronger regularization hurts. The six runs whose validation loss started to rise at the end, all wide models at 2000 iterations, mark where that regime ends.

![Figure 7. Left: exact train vs validation loss of every final model. Right: mean gap by width, depth, training length and dropout.](figures/fig_overfitting.png)

### 4.5 Context length and fair comparisons

**Loss by position** (Fig. 8, left). With one character of context, every model scores about 2.57. The loss falls steeply up to ~8 characters, roughly a word, which is n-gram-like spelling knowledge. After that it falls slowly. For the eight strongest 128-block models, it goes from 1.748 at 4–8 characters to 1.681 at 56–64, and to 1.686 at 120–128: **no further gain beyond about 64 characters**. The strongest 64-block models gain less over the same range (1.806 → 1.774). Averaged over all runs, the curves flatten after ~16 characters. So the models use context up to roughly a line of verse, and only the better-trained ones benefit from more.

**Equal-token comparisons** (Fig. 8, right). block_size 128 lowers loss in 49 of the 64 matched pairs, but a 128-block batch also contains twice the tokens. The grid contains pairs that process exactly the same number of training tokens. In each of three comparisons (32 matched pairs each), **the option with more steps or more separate sequences won every pair**:

| Same tokens, different shape | Mean Δ val (first − second) | First better in |
|---|---|---|
| block 128, batch 8 vs block 64, batch 16 | +0.096 | 0 / 32 |
| block 128, 1000 iters vs block 64, 2000 iters | +0.161 | 0 / 32 |
| batch 16, 1000 iters vs batch 8, 2000 iters | +0.065 | 0 / 32 |

At a fixed number of tokens, then, **a longer context window is worth less than more separate sequences per batch, and both are worth less than more optimizer steps**. The block_size main effect mostly reflects extra data per step, not the longer context. This is the slides' "compare fairly" warning in numbers: ranking the factors by their raw main effects overstates block_size and batch_size relative to max_iters.

![Figure 8. Left: validation loss at each position in the window, averaged over all runs and over the eight strongest runs of each block size. Right: equal-token comparisons.](figures/fig_context.png)

### 4.6 Generated samples

Samples from four models (prompt "\n", temperature 0.8, top-k 200, seed 1337; first 400 characters):

**Best model**, our slice `b128_l6_h8_e256_bs16_it2000_d0.1` (val 1.652; 83% valid words):

```
All before with a purson, but be set bubded eyes
Brid my called heaven that us he her barded.

HENRY BOLINGBROKE:
There one heavens, to that I commillow;
What I is enten mining is the overty and the news
And and self a dise of the mile with at princess,
```

**Best block-64 model** `b64_l4_h8_e256_bs16_it2000_d0.1` (val 1.757; 79%):

```
ANGELO:
And come, which you that see but our take On.

MARCKINGHAM:
Whith foul hath you hearts of endrect my facest,
And I make what to that I could well and
ever weet not millivent drove to the vill.
```

**Median model** `b64_l6_h4_e128_bs16_it2000_d0.2` (val 2.033; 62%):

```
And the Rord cown, whis so be madisen bube to tanth
Sand me tat of bart that us he he to comelt
Hate arche my feanstar my to he ownt
```

**Worst model** `b128_l4_h4_e128_bs8_it1000_d0.2` (val 2.350; 27%):

```
CARET:
Rord wcowild tis s, be matise myobe t e.
Sthend my dalatanss ar hapar us he he.
War dilas ate ar ce myounghedar m o our
```

Every model, even the worst, has learned the *format*: speaker names in capitals followed by a colon, verse-length lines, and a capital letter at the start of each line. The worst model writes mostly pseudo-words. The median model spells common short words ("the", "and", "that", "my") but little else. The best models produce real character names (HENRY BOLINGBROKE from *Richard II*; ANGELO and DUKE VINCENTIO from *Measure for Measure*) next to invented ones (MARCKINGHAM), mostly real words and some grammatical fragments ("which you that see", "I could well"). They have no sentence-level meaning or coherence across lines. Long-range structure, such as a speaker addressing someone named earlier or a rhyme scheme, does not appear in any sample. That matches the context analysis: the models use roughly a line of context. The valid-word rate tracks validation loss closely across all 128 runs (correlation −0.96; Fig. 9), so validation loss is a good proxy for the qualitative quality of the text in this range.

![Figure 9. Share of real words in each model's 500-character sample against its validation loss.](figures/fig_samples.png){4.3}

## 5. Analysis

**The regime decides the ranking.** All 128 runs see between 0.5M and 4.1M training tokens, 0.5 to 4 passes over the 1M-character training set. Every validation curve is still falling, and the gaps are small. In this **compute-limited, under-fitted regime**, whatever increases the amount of learning per run wins:

- more optimizer steps (max_iters);
- more data per step (batch_size, block_size);
- more capacity per step (n_embd).

Whatever removes learning, here dropout 0.2, loses. With a 5000-iteration budget like nanoGPT's default Shakespeare config, the trade-off would shift: the gap would keep growing (6 runs already turn upward), and the higher dropout would start to pay off. Our conclusions are about this budget, not about these architectures in general.

**Width beats depth at this scale.** n_embd 256 is the strongest single factor, and it is nearly free in time because the GPU is far from saturated. Depth costs 35–40% more step time for a 0.014 gain, and it only helps the narrow models. With 1–2k steps, adding layers makes optimization harder (a longer gradient path, smaller initial residual projections) more than it adds useful capacity.

**Heads do not matter.** Splitting a fixed n_embd into 4 or 8 heads changes neither the parameter count nor the loss (+0.0003). For a 65-character vocabulary and windows of 64–128 characters, 4 heads of size 32–64 already capture the patterns the model can learn in this budget.

**"More data" has a hierarchy.** At equal tokens, more steps (2000 iterations at half the batch) beat bigger batches, and bigger batches beat longer windows, in every one of 32 matched pairs (Section 4.5). Each step lets the optimizer move the parameters. A batch of separate sequences gives more varied gradient samples than one long sequence, whose positions are strongly correlated. And positions beyond ~64 characters add little learnable signal for these models.

**Wall-clock time is a poor proxy for model size here.** Time scaled with iterations × layers, not with parameters or FLOPs. nanoGPT's own log reports a model-FLOP utilization of at most about 1% (of an A100's peak). The tip "keep computational budgets similar" therefore has two answers: by tokens, compare at equal batch × block × iterations, as in Section 4.5; by time, compare along the frontier in Fig. 6, where wide 4-layer models are the most efficient.

**Noise and reproducibility.** Seed-to-seed variation (σ ≈ 0.01) is small next to every effect we discuss. It does matter when ranking individual runs: the top four configurations are statistically tied. Same-seed reruns reproduced the losses. Timing, on the other hand, was easy to corrupt: one background game made runs 3× slower. Our timing numbers come from an idle machine, verified with the seed repeats.

## 6. Conclusion

- **Code.** nanoGPT is a pre-norm, weight-tied GPT. Its causal mask comes from the fused SDPA kernel (or a `tril` buffer), and its positional embeddings are learned. Training uses warmup plus cosine decay with optional gradient accumulation, on contiguous 90/10 splits read through `np.memmap`. Generation crops the context to block_size and samples with temperature and top-k.
- **Most important hyperparameters.** For training budgets of 1–2k iterations on Tiny Shakespeare, the most important choices are **width (n_embd), training length (max_iters) and batch size**, followed by **lower dropout**. Block size and depth matter little, and the number of heads not at all. The best configuration, block 128, 256-wide, batch 16, 2000 iterations and dropout 0.1, reaches validation loss 1.65 in 15–20 s on one GPU, with either 4 or 6 layers and either 4 or 8 heads.
- **Lessons learned.**
  - Measure noise before ranking. Without the seed repeats we would have crowned a single "best" run from four tied ones.
  - Compare at equal compute. Raw main effects credited block_size with gains that came from extra tokens.
  - Read results in their regime. Dropout hurt here only because no model trained long enough to overfit.
  - Check timings for contention. Wall-clock time depends on what else the machine is doing.
  - Save everything a later step needs. The slides' checkpoint snippet silently breaks `sample.py`.

\pagebreak

## Appendix A: results of every run, by member slice

Exact final losses (Section 3) for every run, sorted by heads, embd, batch, iters and dropout. Bold marks the best validation loss in each slice. Time is the training-loop wall-clock time; peak MB is the peak GPU memory; valid words is the share of real words in a 500-character sample. Every run used seed 1337.

### A1. Member 1, slice [block_size 64, n_layer 4]

| heads | embd | batch | iters | dropout | params | time (s) | peak MB | train | val | gap | valid words |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 4 | 128 | 8 | 1000 | 0.1 | 0.80M | 7.1 | 38 | 2.266 | 2.272 | 0.006 | 29% |
| 4 | 128 | 8 | 1000 | 0.2 | 0.80M | 7.1 | 38 | 2.334 | 2.334 | 0.000 | 23% |
| 4 | 128 | 8 | 2000 | 0.1 | 0.80M | 14.0 | 38 | 2.032 | 2.076 | 0.044 | 46% |
| 4 | 128 | 8 | 2000 | 0.2 | 0.80M | 13.6 | 38 | 2.139 | 2.161 | 0.021 | 50% |
| 4 | 128 | 16 | 1000 | 0.1 | 0.80M | 7.7 | 49 | 2.113 | 2.143 | 0.030 | 47% |
| 4 | 128 | 16 | 1000 | 0.2 | 0.80M | 7.4 | 49 | 2.202 | 2.217 | 0.015 | 47% |
| 4 | 128 | 16 | 2000 | 0.1 | 0.80M | 14.2 | 49 | 1.868 | 1.959 | 0.090 | 68% |
| 4 | 128 | 16 | 2000 | 0.2 | 0.80M | 14.2 | 49 | 1.991 | 2.044 | 0.052 | 63% |
| 4 | 256 | 8 | 1000 | 0.1 | 3.18M | 7.4 | 80 | 1.980 | 2.022 | 0.042 | 58% |
| 4 | 256 | 8 | 1000 | 0.2 | 3.18M | 7.4 | 80 | 2.079 | 2.096 | 0.017 | 52% |
| 4 | 256 | 8 | 2000 | 0.1 | 3.18M | 14.1 | 80 | 1.744 | 1.879 | 0.135 | 74% |
| 4 | 256 | 8 | 2000 | 0.2 | 3.18M | 14.2 | 80 | 1.851 | 1.951 | 0.100 | 73% |
| 4 | 256 | 16 | 1000 | 0.1 | 3.18M | 7.6 | 103 | 1.795 | 1.909 | 0.114 | 71% |
| 4 | 256 | 16 | 1000 | 0.2 | 3.18M | 7.7 | 103 | 1.904 | 1.982 | 0.078 | 70% |
| 4 | 256 | 16 | 2000 | 0.1 | 3.18M | 14.4 | 103 | 1.594 | 1.761 | 0.167 | 88% |
| 4 | 256 | 16 | 2000 | 0.2 | 3.18M | 14.1 | 103 | 1.689 | 1.843 | 0.154 | 75% |
| 8 | 128 | 8 | 1000 | 0.1 | 0.80M | 7.1 | 38 | 2.264 | 2.269 | 0.004 | 29% |
| 8 | 128 | 8 | 1000 | 0.2 | 0.80M | 7.1 | 38 | 2.314 | 2.314 | 0.000 | 31% |
| 8 | 128 | 8 | 2000 | 0.1 | 0.80M | 13.5 | 38 | 2.026 | 2.067 | 0.041 | 50% |
| 8 | 128 | 8 | 2000 | 0.2 | 0.80M | 14.0 | 38 | 2.151 | 2.173 | 0.022 | 45% |
| 8 | 128 | 16 | 1000 | 0.1 | 0.80M | 7.4 | 49 | 2.122 | 2.149 | 0.027 | 47% |
| 8 | 128 | 16 | 1000 | 0.2 | 0.80M | 7.4 | 49 | 2.214 | 2.228 | 0.014 | 35% |
| 8 | 128 | 16 | 2000 | 0.1 | 0.80M | 14.3 | 49 | 1.861 | 1.955 | 0.094 | 66% |
| 8 | 128 | 16 | 2000 | 0.2 | 0.80M | 14.3 | 49 | 1.992 | 2.045 | 0.053 | 59% |
| 8 | 256 | 8 | 1000 | 0.1 | 3.18M | 7.4 | 80 | 2.003 | 2.046 | 0.043 | 53% |
| 8 | 256 | 8 | 1000 | 0.2 | 3.18M | 7.7 | 80 | 2.106 | 2.121 | 0.015 | 55% |
| 8 | 256 | 8 | 2000 | 0.1 | 3.18M | 14.1 | 80 | 1.744 | 1.877 | 0.132 | 73% |
| 8 | 256 | 8 | 2000 | 0.2 | 3.18M | 13.9 | 80 | 1.849 | 1.949 | 0.100 | 73% |
| 8 | 256 | 16 | 1000 | 0.1 | 3.18M | 7.6 | 103 | 1.808 | 1.922 | 0.115 | 63% |
| 8 | 256 | 16 | 1000 | 0.2 | 3.18M | 7.7 | 103 | 1.920 | 1.994 | 0.075 | 59% |
| 8 | 256 | 16 | 2000 | 0.1 | 3.18M | 14.4 | 103 | 1.593 | **1.757** | 0.164 | 79% |
| 8 | 256 | 16 | 2000 | 0.2 | 3.18M | 14.2 | 103 | 1.680 | 1.837 | 0.157 | 82% |

### A2. Member 2, slice [block_size 64, n_layer 6]

| heads | embd | batch | iters | dropout | params | time (s) | peak MB | train | val | gap | valid words |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 4 | 128 | 8 | 1000 | 0.1 | 1.20M | 10.3 | 48 | 2.254 | 2.253 | -0.002 | 34% |
| 4 | 128 | 8 | 1000 | 0.2 | 1.20M | 10.7 | 48 | 2.313 | 2.307 | -0.005 | 27% |
| 4 | 128 | 8 | 2000 | 0.1 | 1.20M | 20.4 | 48 | 2.047 | 2.085 | 0.038 | 54% |
| 4 | 128 | 8 | 2000 | 0.2 | 1.20M | 21.6 | 48 | 2.146 | 2.160 | 0.014 | 37% |
| 4 | 128 | 16 | 1000 | 0.1 | 1.20M | 11.1 | 63 | 2.121 | 2.136 | 0.015 | 45% |
| 4 | 128 | 16 | 1000 | 0.2 | 1.20M | 9.9 | 63 | 2.201 | 2.207 | 0.006 | 33% |
| 4 | 128 | 16 | 2000 | 0.1 | 1.20M | 18.7 | 63 | 1.863 | 1.957 | 0.095 | 64% |
| 4 | 128 | 16 | 2000 | 0.2 | 1.20M | 18.6 | 63 | 1.978 | 2.033 | 0.054 | 62% |
| 4 | 256 | 8 | 1000 | 0.1 | 4.75M | 10.4 | 111 | 1.995 | 2.050 | 0.054 | 53% |
| 4 | 256 | 8 | 1000 | 0.2 | 4.75M | 9.7 | 111 | 2.090 | 2.117 | 0.027 | 48% |
| 4 | 256 | 8 | 2000 | 0.1 | 4.75M | 18.6 | 111 | 1.767 | 1.896 | 0.129 | 75% |
| 4 | 256 | 8 | 2000 | 0.2 | 4.75M | 18.5 | 111 | 1.866 | 1.962 | 0.095 | 69% |
| 4 | 256 | 16 | 1000 | 0.1 | 4.75M | 9.7 | 143 | 1.811 | 1.924 | 0.113 | 64% |
| 4 | 256 | 16 | 1000 | 0.2 | 4.75M | 9.9 | 143 | 1.918 | 1.996 | 0.077 | 69% |
| 4 | 256 | 16 | 2000 | 0.1 | 4.75M | 19.2 | 143 | 1.598 | **1.758** | 0.160 | 78% |
| 4 | 256 | 16 | 2000 | 0.2 | 4.75M | 19.0 | 143 | 1.692 | 1.840 | 0.149 | 76% |
| 8 | 128 | 8 | 1000 | 0.1 | 1.20M | 9.3 | 48 | 2.245 | 2.247 | 0.002 | 36% |
| 8 | 128 | 8 | 1000 | 0.2 | 1.20M | 9.2 | 48 | 2.294 | 2.289 | -0.005 | 32% |
| 8 | 128 | 8 | 2000 | 0.1 | 1.20M | 18.5 | 48 | 2.019 | 2.056 | 0.037 | 47% |
| 8 | 128 | 8 | 2000 | 0.2 | 1.20M | 17.2 | 48 | 2.112 | 2.129 | 0.017 | 45% |
| 8 | 128 | 16 | 1000 | 0.1 | 1.20M | 9.5 | 64 | 2.100 | 2.119 | 0.019 | 38% |
| 8 | 128 | 16 | 1000 | 0.2 | 1.20M | 9.5 | 64 | 2.193 | 2.199 | 0.006 | 36% |
| 8 | 128 | 16 | 2000 | 0.1 | 1.20M | 19.1 | 64 | 1.839 | 1.937 | 0.098 | 63% |
| 8 | 128 | 16 | 2000 | 0.2 | 1.20M | 19.0 | 64 | 1.959 | 2.020 | 0.062 | 59% |
| 8 | 256 | 8 | 1000 | 0.1 | 4.75M | 9.7 | 111 | 2.011 | 2.060 | 0.050 | 49% |
| 8 | 256 | 8 | 1000 | 0.2 | 4.75M | 9.6 | 111 | 2.107 | 2.130 | 0.022 | 51% |
| 8 | 256 | 8 | 2000 | 0.1 | 4.75M | 18.7 | 111 | 1.764 | 1.883 | 0.119 | 68% |
| 8 | 256 | 8 | 2000 | 0.2 | 4.75M | 18.9 | 111 | 1.861 | 1.954 | 0.093 | 71% |
| 8 | 256 | 16 | 1000 | 0.1 | 4.75M | 9.9 | 143 | 1.815 | 1.927 | 0.112 | 74% |
| 8 | 256 | 16 | 1000 | 0.2 | 4.75M | 9.6 | 143 | 1.924 | 1.993 | 0.069 | 65% |
| 8 | 256 | 16 | 2000 | 0.1 | 4.75M | 18.2 | 143 | 1.596 | 1.761 | 0.166 | 78% |
| 8 | 256 | 16 | 2000 | 0.2 | 4.75M | 18.7 | 143 | 1.674 | 1.821 | 0.147 | 73% |

### A3. Member 3, slice [block_size 128, n_layer 4]

| heads | embd | batch | iters | dropout | params | time (s) | peak MB | train | val | gap | valid words |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 4 | 128 | 8 | 1000 | 0.1 | 0.81M | 7.5 | 49 | 2.282 | 2.296 | 0.014 | 26% |
| 4 | 128 | 8 | 1000 | 0.2 | 0.81M | 7.8 | 49 | 2.347 | 2.350 | 0.003 | 27% |
| 4 | 128 | 8 | 2000 | 0.1 | 0.81M | 14.8 | 49 | 2.027 | 2.082 | 0.055 | 51% |
| 4 | 128 | 8 | 2000 | 0.2 | 0.81M | 15.1 | 49 | 2.151 | 2.176 | 0.026 | 35% |
| 4 | 128 | 16 | 1000 | 0.1 | 0.81M | 8.8 | 72 | 2.136 | 2.162 | 0.026 | 41% |
| 4 | 128 | 16 | 1000 | 0.2 | 0.81M | 8.8 | 72 | 2.225 | 2.241 | 0.016 | 37% |
| 4 | 128 | 16 | 2000 | 0.1 | 0.81M | 16.0 | 72 | 1.838 | 1.934 | 0.096 | 74% |
| 4 | 128 | 16 | 2000 | 0.2 | 0.81M | 15.6 | 72 | 1.975 | 2.034 | 0.058 | 66% |
| 4 | 256 | 8 | 1000 | 0.1 | 3.20M | 8.5 | 103 | 1.921 | 2.001 | 0.080 | 61% |
| 4 | 256 | 8 | 1000 | 0.2 | 3.20M | 9.1 | 103 | 2.087 | 2.125 | 0.037 | 59% |
| 4 | 256 | 8 | 2000 | 0.1 | 3.20M | 17.7 | 103 | 1.631 | 1.784 | 0.153 | 77% |
| 4 | 256 | 8 | 2000 | 0.2 | 3.20M | 15.0 | 103 | 1.744 | 1.873 | 0.129 | 76% |
| 4 | 256 | 16 | 1000 | 0.1 | 3.20M | 8.1 | 146 | 1.714 | 1.854 | 0.140 | 70% |
| 4 | 256 | 16 | 1000 | 0.2 | 3.20M | 7.9 | 146 | 1.853 | 1.959 | 0.106 | 62% |
| 4 | 256 | 16 | 2000 | 0.1 | 3.20M | 15.3 | 146 | 1.481 | **1.654** | 0.173 | 85% |
| 4 | 256 | 16 | 2000 | 0.2 | 3.20M | 15.7 | 146 | 1.583 | 1.744 | 0.161 | 80% |
| 8 | 128 | 8 | 1000 | 0.1 | 0.81M | 7.3 | 49 | 2.258 | 2.270 | 0.012 | 30% |
| 8 | 128 | 8 | 1000 | 0.2 | 0.81M | 7.6 | 49 | 2.331 | 2.335 | 0.003 | 31% |
| 8 | 128 | 8 | 2000 | 0.1 | 0.81M | 14.4 | 49 | 2.005 | 2.060 | 0.055 | 53% |
| 8 | 128 | 8 | 2000 | 0.2 | 0.81M | 14.0 | 49 | 2.126 | 2.157 | 0.030 | 50% |
| 8 | 128 | 16 | 1000 | 0.1 | 0.81M | 8.0 | 72 | 2.123 | 2.149 | 0.026 | 39% |
| 8 | 128 | 16 | 1000 | 0.2 | 0.81M | 8.1 | 72 | 2.217 | 2.235 | 0.018 | 35% |
| 8 | 128 | 16 | 2000 | 0.1 | 0.81M | 15.4 | 72 | 1.815 | 1.918 | 0.103 | 66% |
| 8 | 128 | 16 | 2000 | 0.2 | 0.81M | 15.3 | 72 | 1.957 | 2.021 | 0.064 | 59% |
| 8 | 256 | 8 | 1000 | 0.1 | 3.20M | 8.2 | 103 | 1.970 | 2.041 | 0.071 | 57% |
| 8 | 256 | 8 | 1000 | 0.2 | 3.20M | 7.8 | 103 | 2.126 | 2.168 | 0.042 | 41% |
| 8 | 256 | 8 | 2000 | 0.1 | 3.20M | 15.0 | 103 | 1.638 | 1.790 | 0.151 | 79% |
| 8 | 256 | 8 | 2000 | 0.2 | 3.20M | 15.0 | 103 | 1.757 | 1.882 | 0.124 | 76% |
| 8 | 256 | 16 | 1000 | 0.1 | 3.20M | 8.4 | 146 | 1.755 | 1.884 | 0.129 | 78% |
| 8 | 256 | 16 | 1000 | 0.2 | 3.20M | 8.5 | 146 | 1.910 | 1.992 | 0.083 | 63% |
| 8 | 256 | 16 | 2000 | 0.1 | 3.20M | 18.2 | 146 | 1.476 | 1.655 | 0.180 | 88% |
| 8 | 256 | 16 | 2000 | 0.2 | 3.20M | 17.5 | 146 | 1.573 | 1.739 | 0.166 | 82% |

### A4. Member 4, slice [block_size 128, n_layer 6] (our assigned slice)

| heads | embd | batch | iters | dropout | params | time (s) | peak MB | train | val | gap | valid words |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 4 | 128 | 8 | 1000 | 0.1 | 1.21M | 9.6 | 64 | 2.237 | 2.244 | 0.007 | 33% |
| 4 | 128 | 8 | 1000 | 0.2 | 1.21M | 11.6 | 64 | 2.285 | 2.285 | 0.000 | 31% |
| 4 | 128 | 8 | 2000 | 0.1 | 1.21M | 18.5 | 64 | 1.980 | 2.038 | 0.059 | 59% |
| 4 | 128 | 8 | 2000 | 0.2 | 1.21M | 17.5 | 64 | 2.088 | 2.120 | 0.032 | 47% |
| 4 | 128 | 16 | 1000 | 0.1 | 1.21M | 10.5 | 97 | 2.068 | 2.102 | 0.034 | 47% |
| 4 | 128 | 16 | 1000 | 0.2 | 1.21M | 9.6 | 97 | 2.183 | 2.201 | 0.018 | 35% |
| 4 | 128 | 16 | 2000 | 0.1 | 1.21M | 18.6 | 97 | 1.760 | 1.882 | 0.122 | 70% |
| 4 | 128 | 16 | 2000 | 0.2 | 1.21M | 18.8 | 97 | 1.895 | 1.972 | 0.077 | 60% |
| 4 | 256 | 8 | 1000 | 0.1 | 4.77M | 9.8 | 143 | 1.932 | 2.008 | 0.076 | 65% |
| 4 | 256 | 8 | 1000 | 0.2 | 4.77M | 10.0 | 143 | 2.085 | 2.121 | 0.035 | 54% |
| 4 | 256 | 8 | 2000 | 0.1 | 4.77M | 19.4 | 143 | 1.649 | 1.798 | 0.148 | 80% |
| 4 | 256 | 8 | 2000 | 0.2 | 4.77M | 18.7 | 143 | 1.768 | 1.898 | 0.130 | 75% |
| 4 | 256 | 16 | 1000 | 0.1 | 4.77M | 10.1 | 209 | 1.723 | 1.854 | 0.131 | 76% |
| 4 | 256 | 16 | 1000 | 0.2 | 4.77M | 10.1 | 209 | 1.848 | 1.950 | 0.102 | 64% |
| 4 | 256 | 16 | 2000 | 0.1 | 4.77M | 20.1 | 209 | 1.487 | 1.664 | 0.177 | 88% |
| 4 | 256 | 16 | 2000 | 0.2 | 4.77M | 19.8 | 209 | 1.567 | 1.734 | 0.167 | 84% |
| 8 | 128 | 8 | 1000 | 0.1 | 1.21M | 9.7 | 64 | 2.219 | 2.227 | 0.008 | 33% |
| 8 | 128 | 8 | 1000 | 0.2 | 1.21M | 9.7 | 64 | 2.281 | 2.283 | 0.002 | 31% |
| 8 | 128 | 8 | 2000 | 0.1 | 1.21M | 18.8 | 64 | 1.951 | 2.016 | 0.066 | 52% |
| 8 | 128 | 8 | 2000 | 0.2 | 1.21M | 18.9 | 64 | 2.072 | 2.103 | 0.031 | 46% |
| 8 | 128 | 16 | 1000 | 0.1 | 1.21M | 10.0 | 97 | 2.064 | 2.094 | 0.030 | 41% |
| 8 | 128 | 16 | 1000 | 0.2 | 1.21M | 9.6 | 97 | 2.173 | 2.190 | 0.017 | 46% |
| 8 | 128 | 16 | 2000 | 0.1 | 1.21M | 19.6 | 97 | 1.739 | 1.867 | 0.128 | 75% |
| 8 | 128 | 16 | 2000 | 0.2 | 1.21M | 19.4 | 97 | 1.882 | 1.965 | 0.083 | 64% |
| 8 | 256 | 8 | 1000 | 0.1 | 4.77M | 9.8 | 143 | 1.995 | 2.061 | 0.066 | 60% |
| 8 | 256 | 8 | 1000 | 0.2 | 4.77M | 9.7 | 143 | 2.140 | 2.177 | 0.037 | 45% |
| 8 | 256 | 8 | 2000 | 0.1 | 4.77M | 18.6 | 143 | 1.653 | 1.795 | 0.142 | 79% |
| 8 | 256 | 8 | 2000 | 0.2 | 4.77M | 18.7 | 143 | 1.769 | 1.891 | 0.121 | 71% |
| 8 | 256 | 16 | 1000 | 0.1 | 4.77M | 11.0 | 209 | 1.753 | 1.877 | 0.124 | 67% |
| 8 | 256 | 16 | 1000 | 0.2 | 4.77M | 10.7 | 209 | 1.932 | 2.013 | 0.080 | 71% |
| 8 | 256 | 16 | 2000 | 0.1 | 4.77M | 20.4 | 209 | 1.467 | **1.652** | 0.185 | 83% |
| 8 | 256 | 16 | 2000 | 0.2 | 4.77M | 19.6 | 209 | 1.590 | 1.758 | 0.168 | 76% |

## Appendix B: repository and reproduction

| Path | Contents |
|---|---|
| `nanoGPT/` | karpathy/nanoGPT at commit 3adf61e (MIT license), with `train.py` patched as in `train_py.patch` |
| `upstream/train.py` | the unmodified upstream `train.py`, for the diff |
| `grid.py` | the 128-config grid and seed repeats; runs `train.py` once per config and skips finished runs |
| `runs/<name>/` | `train.log` (complete stdout), `summary.json` (config, time, memory), `eval.json` (exact losses, per-position loss, sample); checkpoints are not committed |
| `runs_slow_archive/` | first-pass logs of our slice, slowed by the background game (Section 3) |
| `nanogpt_experiments.py` → `nanogpt_experiments.ipynb` | the analysis notebook: data, patch, training (skips finished runs), exact evaluation, every table and figure |
| `results.csv`, `results.json` | one row per grid run; every number quoted in this report |
| `figures/` | all figures in this report |

To reproduce: run `python nanoGPT/data/shakespeare_char/prepare.py` from inside `nanoGPT/` to download and encode the data, then `python grid.py` (about 30 minutes of training on an RTX 5090), then `python run_notebook.py`. Run names encode the config, for example `b128_l6_h8_e256_bs16_it2000_d0.1` is block 128, 6 layers, 8 heads, n_embd 256, batch 16, 2000 iterations, dropout 0.1.
