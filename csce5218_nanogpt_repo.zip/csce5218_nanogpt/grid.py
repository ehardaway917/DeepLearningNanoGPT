"""Run the 2^7 = 128-config nanoGPT hyperparameter grid (plus seed repeats).

Each run calls nanoGPT's own train.py (nanoGPT/, commit 3adf61e, patched only to
take a --seed and to save a final checkpoint + run summary) on the character-level
Shakespeare data, one run at a time so wall-clock times are comparable.

    python grid.py                 # run everything that has not finished yet
    python grid.py --slice 128 6   # only one member's slice

Outputs per run in runs/<name>/: train.log (full stdout), ckpt.pt (final model),
summary.json (config, wall-clock, peak memory, status). Finished runs are skipped.
"""
import argparse
import itertools
import json
import os
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.abspath(__file__))
NANOGPT = os.path.join(ROOT, "nanoGPT")
RUNS = os.path.join(ROOT, "runs")

# Factor levels from the assignment slides, in the slide's order:
# [block_size, n_layer, n_head, n_embd, batch_size, max_iters, dropout]
FACTORS = {
    "block_size": [64, 128],
    "n_layer": [4, 6],
    "n_head": [4, 8],
    "n_embd": [128, 256],
    "batch_size": [8, 16],
    "max_iters": [1000, 2000],
    "dropout": [0.1, 0.2],
}
# Group split from the slides: one member per (block_size, n_layer) slice.
SLICE_ORDER = [(128, 6), (128, 4), (64, 6), (64, 4)]   # our slice (128, 6) runs first

# Settings shared by every run (everything else comes from config/train_shakespeare_char.py:
# lr 1e-3 -> min_lr 1e-4 cosine, warmup 100, AdamW beta2 0.99, weight decay 0.1, grad clip 1.0).
COMMON = {
    "compile": False,
    "eval_interval": 100,     # loss curve every 100 iterations
    "eval_iters": 40,         # batches per estimate during training (final losses are re-measured exactly)
    "log_interval": 10,
}
BASE_SEED = 1337
# Seed repeats to measure run-to-run noise: four configs spanning the grid, two extra seeds each.
REPEAT_CONFIGS = [
    (64, 4, 4, 128, 8, 1000, 0.1),      # smallest / cheapest corner
    (128, 6, 8, 256, 16, 2000, 0.2),    # largest / most expensive corner
    (128, 6, 4, 128, 16, 2000, 0.1),    # from our slice, mid-size
    (64, 6, 8, 256, 8, 1000, 0.2),      # mixed corner
]
REPEAT_SEEDS = [1338, 1339]


def run_name(cfg, seed=BASE_SEED):
    b, l, h, e, bs, it, d = cfg
    name = f"b{b}_l{l}_h{h}_e{e}_bs{bs}_it{it}_d{d}"
    return name if seed == BASE_SEED else f"{name}_s{seed}"


def all_configs():
    """All 128 configs, ordered slice by slice (our slice first)."""
    rest = list(itertools.product(*[FACTORS[k] for k in list(FACTORS)[2:]]))
    return [(b, l, *r) for b, l in SLICE_ORDER for r in rest]


def all_jobs():
    jobs = [(cfg, BASE_SEED) for cfg in all_configs()]
    jobs += [(cfg, s) for cfg in REPEAT_CONFIGS for s in REPEAT_SEEDS]
    return jobs


def cfg_dict(cfg):
    return dict(zip(FACTORS, cfg))


def run_one(cfg, seed=BASE_SEED, force=False):
    name = run_name(cfg, seed)
    out = os.path.join(RUNS, name)
    summary_path = os.path.join(out, "summary.json")
    if os.path.exists(summary_path) and not force:
        with open(summary_path) as f:
            s = json.load(f)
        if s.get("status") == "ok":
            return s, False
    os.makedirs(out, exist_ok=True)
    c = cfg_dict(cfg)
    args = {**COMMON, **c, "lr_decay_iters": c["max_iters"], "seed": seed,
            "out_dir": os.path.relpath(out, NANOGPT).replace("\\", "/")}
    cmd = [sys.executable, "train.py", "config/train_shakespeare_char.py"] + [f"--{k}={v}" for k, v in args.items()]
    t0 = time.time()
    with open(os.path.join(out, "train.log"), "w", encoding="utf-8") as log:
        log.write("COMMAND: " + " ".join(cmd) + "\n")
        log.flush()
        proc = subprocess.run(cmd, cwd=NANOGPT, stdout=log, stderr=subprocess.STDOUT, text=True)
    wall = time.time() - t0
    run_summary = {}
    with open(os.path.join(out, "train.log"), encoding="utf-8") as f:
        for line in f:
            if line.startswith("RUN_SUMMARY "):
                run_summary = json.loads(line[len("RUN_SUMMARY "):])
    s = {"name": name, **c, "seed": seed, "lr_decay_iters": c["max_iters"], **COMMON,
         "process_wall_s": wall, **run_summary,
         "status": "ok" if proc.returncode == 0 and run_summary else f"failed (exit {proc.returncode})"}
    with open(summary_path, "w") as f:
        json.dump(s, f, indent=1)
    return s, True


def run_all(jobs=None, verbose=True):
    jobs = jobs if jobs is not None else all_jobs()
    t_start, done_now = time.time(), 0
    for i, (cfg, seed) in enumerate(jobs):
        s, ran = run_one(cfg, seed)
        done_now += ran
        if verbose and ran:
            print(f"[{i + 1:3d}/{len(jobs)}] {s['name']:40s} {s['status']:6s} "
                  f"train {s.get('train_time_s', float('nan')):6.1f}s  peak {s.get('peak_mem_mb', float('nan')):6.0f} MB  "
                  f"(elapsed {(time.time() - t_start) / 60:.1f} min)", flush=True)
    failed = [run_name(c, s) for c, s in jobs
              if json.load(open(os.path.join(RUNS, run_name(c, s), "summary.json"))).get("status") != "ok"]
    print(f"{len(jobs)} runs: {done_now} trained now, {len(jobs) - done_now} already done, {len(failed)} failed",
          flush=True)
    return failed


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--slice", nargs=2, type=int, metavar=("BLOCK", "LAYERS"))
    a = ap.parse_args()
    jobs = all_jobs()
    if a.slice:
        jobs = [(c, s) for c, s in jobs if tuple(c[:2]) == tuple(a.slice)]
    run_all(jobs)
