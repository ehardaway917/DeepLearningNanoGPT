# %% [markdown]
# # nanoGPT hyperparameter experiments: character-level Shakespeare
#
# CSCE 5218 Deep Learning (Amir Mirzaeinia), nanoGPT assignment, Part 2.
#
# The full 2^7 = 128-config grid from the slides,
# `[block_size, n_layer, n_head, n_embd, batch_size, max_iters, dropout]`, trained
# with nanoGPT's own `train.py` (karpathy/nanoGPT, commit 3adf61e) on Tiny
# Shakespeare, one run at a time on one GPU. Four configs were also rerun with two
# extra seeds, to measure how much of the differences is run-to-run noise.
#
# The slides assign one (block_size, n_layer) slice of 32 runs to each group
# member. Our slice is **[128, 6, \*, \*, \*, \*, \*]**; the other three slices were
# run too, so that the report does not depend on any single member's runs.
#
# Pipeline:
# 1. Data and the patched `train.py` (diff printed below).
# 2. Train every run (`grid.py`; finished runs are skipped, logs in `runs/<name>/train.log`).
# 3. Parse the training logs (loss curves every 100 iterations, iteration times).
# 4. Re-measure every final model **exactly**: loss on the whole validation split
#    and on an equal-sized fixed sample of the training split, loss by position in
#    the context window, and a 500-character sample (seed 1337, temperature 0.8,
#    top-k 200, as in `sample.py`).
# 5. Analysis: tables, factorial main effects and interactions against seed noise,
#    cost (time, memory, parameters), overfitting, context length, sample quality.

# %%
import contextlib
import difflib
import io
import json
import math
import os
import pickle
import re
import subprocess
import sys
import time

import matplotlib

try:
    get_ipython  # defined only inside Jupyter/IPython
    IN_NOTEBOOK = True
except NameError:
    IN_NOTEBOOK = False
    matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F

ROOT = os.path.dirname(os.path.abspath("grid.py"))
NANOGPT = os.path.join(ROOT, "nanoGPT")
sys.path.insert(0, NANOGPT)
sys.path.insert(0, ROOT)
import grid                                   # noqa: E402
from model import GPT, GPTConfig              # noqa: E402  (nanoGPT's model.py)

DATA = os.path.join(NANOGPT, "data", "shakespeare_char")
FIG_DIR = os.path.join(ROOT, "figures")
os.makedirs(FIG_DIR, exist_ok=True)
device = "cuda" if torch.cuda.is_available() else "cpu"
FACTORS = list(grid.FACTORS)
SHORT = {"block_size": "block", "n_layer": "layers", "n_head": "heads", "n_embd": "embd",
         "batch_size": "batch", "max_iters": "iters", "dropout": "dropout"}
OUR_SLICE = (128, 6)
SLICE_LABEL = {(64, 4): "member 1 [64, 4]", (64, 6): "member 2 [64, 6]",
               (128, 4): "member 3 [128, 4]", (128, 6): "member 4 [128, 6] (ours)"}
RESULTS = {}

# Validated categorical palette (fixed order); grays for de-emphasis.
BLUE, ORANGE, AQUA, YELLOW = "#2a78d6", "#eb6834", "#1baf7a", "#eda100"
SLICE_COLOR = {(64, 4): BLUE, (64, 6): ORANGE, (128, 4): AQUA, (128, 6): YELLOW}
INK, MUTED, LIGHT = "#2b2b2a", "#8a8984", "#d9d8d3"
plt.rcParams.update({"figure.dpi": 110, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.grid": True, "grid.color": "#e4e3df", "grid.linewidth": 0.8,
                     "axes.edgecolor": MUTED, "lines.linewidth": 1.5, "font.size": 9.5})


def show(fig, name):
    fig.savefig(os.path.join(FIG_DIR, name), bbox_inches="tight", dpi=150)
    if IN_NOTEBOOK:
        plt.show()
    else:
        plt.close(fig)


print("device:", device, "| torch", torch.__version__)
print("nanoGPT commit:", open(os.path.join(ROOT, "upstream", "COMMIT")).read().strip())

# %% [markdown]
# ## 1. Data, configuration and the train.py patch
#
# `prepare.py` splits Tiny Shakespeare (1,115,394 characters, 65 symbols) into the
# first 90% for training and the last 10% for validation, and stores both as
# uint16 token ids. `train.py` reads them through `np.memmap`, so random windows
# are sliced straight out of the file.
#
# Every run uses `config/train_shakespeare_char.py` plus the grid values. The
# fixed settings are: AdamW, lr 1e-3 with 100 warmup iterations and cosine decay
# to 1e-4, beta2 0.99, weight decay 0.1, gradient clip 1.0, no bias, bf16
# autocast, no `torch.compile`, and gradient accumulation 1. `lr_decay_iters` is
# set equal to `max_iters`, as nanoGPT recommends, so the 1000-iteration runs
# also finish their decay. Losses are estimated every 100 iterations on 40
# batches per split.

# %%
meta = pickle.load(open(os.path.join(DATA, "meta.pkl"), "rb"))
itos, stoi, VOCAB = meta["itos"], meta["stoi"], meta["vocab_size"]
train_ids = np.memmap(os.path.join(DATA, "train.bin"), dtype=np.uint16, mode="r")
val_ids = np.memmap(os.path.join(DATA, "val.bin"), dtype=np.uint16, mode="r")
train_text = "".join(itos[int(i)] for i in train_ids)
TRAIN_WORDS = set(re.findall(r"[a-z']+", train_text.lower()))
print(f"vocab {VOCAB} | train {len(train_ids):,} tokens | val {len(val_ids):,} tokens | "
      f"{len(TRAIN_WORDS):,} distinct training words")
print(f"uniform-guess loss ln(65) = {math.log(VOCAB):.3f}")
RESULTS["data"] = {"vocab": VOCAB, "train_tokens": len(train_ids), "val_tokens": len(val_ids)}

print(open(os.path.join(NANOGPT, "config", "train_shakespeare_char.py")).read())
# Our only change to nanoGPT: the diff of train.py against the pristine upstream copy.
with open(os.path.join(ROOT, "upstream", "train.py"), encoding="utf-8") as f:
    upstream_lines = f.read().splitlines(keepends=True)
with open(os.path.join(NANOGPT, "train.py"), encoding="utf-8") as f:
    patched_lines = f.read().splitlines(keepends=True)
diff = "".join(difflib.unified_diff(upstream_lines, patched_lines, "upstream/train.py", "nanoGPT/train.py"))
with open(os.path.join(ROOT, "train_py.patch"), "w", encoding="utf-8") as f:
    f.write(diff)
print(diff)

# %%
# The learning-rate schedule of the two max_iters settings, computed with
# train.py's own get_lr logic.
def get_lr(it, max_iters, learning_rate=1e-3, min_lr=1e-4, warmup_iters=100):
    lr_decay_iters = max_iters
    if it < warmup_iters:
        return learning_rate * (it + 1) / (warmup_iters + 1)
    if it > lr_decay_iters:
        return min_lr
    ratio = (it - warmup_iters) / (lr_decay_iters - warmup_iters)
    return min_lr + 0.5 * (1.0 + math.cos(math.pi * ratio)) * (learning_rate - min_lr)


fig, ax = plt.subplots(figsize=(6, 2.6))
for mi, color in [(1000, BLUE), (2000, ORANGE)]:
    its = np.arange(0, mi + 1)
    ax.plot(its, [get_lr(i, mi) for i in its], color=color, label=f"max_iters = lr_decay_iters = {mi}")
ax.set_xlabel("iteration")
ax.set_ylabel("learning rate")
ax.set_title("Learning-rate schedule: 100-step warmup, cosine decay to min_lr", fontsize=10)
ax.legend(frameon=False)
show(fig, "fig_lr_schedule.png")

# %% [markdown]
# ## 2. Train the grid
#
# `grid.run_all()` trains every config that has no finished `summary.json`, one at
# a time, and skips the rest. The full grid took about 1.5 hours on an RTX 5090.
# Each run directory holds the complete stdout of `train.py`.

# %%
failed = grid.run_all()
assert not failed, failed

# %% [markdown]
# ## 3. Parse the training logs

# %%
EVAL_RE = re.compile(r"^step (\d+): train loss ([\d.]+), val loss ([\d.]+)")
ITER_RE = re.compile(r"^iter (\d+): loss ([\d.]+), time ([\d.]+)ms")


def parse_log(path):
    evals, iters = [], []
    with open(path, encoding="utf-8") as f:
        for line in f:
            m = EVAL_RE.match(line)
            if m:
                evals.append((int(m[1]), float(m[2]), float(m[3])))
                continue
            m = ITER_RE.match(line)
            if m:
                iters.append((int(m[1]), float(m[2]), float(m[3])))
    return (pd.DataFrame(evals, columns=["step", "train", "val"]),
            pd.DataFrame(iters, columns=["iter", "loss", "ms"]))


jobs = grid.all_jobs()
runs = []
curves = {}
for cfg, seed in jobs:
    name = grid.run_name(cfg, seed)
    d = os.path.join(grid.RUNS, name)
    s = json.load(open(os.path.join(d, "summary.json")))
    ev, it = parse_log(os.path.join(d, "train.log"))
    curves[name] = ev
    # Iterations logged right after an evaluation include the eval time; drop those.
    step_ms = it[(it.iter % grid.COMMON["eval_interval"] != 0) & (it.iter > 0)].ms
    runs.append({**s, "median_step_ms": float(step_ms.median()),
                 "est_step_time_s": float(step_ms.median() * s["max_iters"] / 1000),
                 "log_best_val": float(ev.val.min()), "log_final_train": float(ev.train.iloc[-1]),
                 "log_final_val": float(ev.val.iloc[-1])})
runs = pd.DataFrame(runs)
runs["tokens_seen"] = runs.batch_size * runs.block_size * runs.max_iters
print(len(runs), "runs parsed;", (runs.status == "ok").sum(), "ok")
runs[["name", "n_params", "train_time_s", "median_step_ms", "peak_mem_mb", "log_final_val"]].head()

# %% [markdown]
# ## 4. Exact evaluation of every final model
#
# The losses that `train.py` prints come from 40 random batches, which for the
# smallest batches is about 20k tokens. That is too noisy to rank 128 runs
# against each other. So every final checkpoint is re-measured deterministically
# in float32, on:
#
# * **val**: the whole validation split, cut into non-overlapping windows of the
#   run's block_size (110k+ target tokens);
# * **train**: the same number of windows at fixed random offsets in the training
#   split (seed 0), so the train-val gap compares equal-sized samples;
# * **loss by position**: the validation loss at each position 0..T-1 in the
#   window, showing how much each extra character of context helps;
# * **sample**: 500 new characters from the prompt "\n" with sample.py's defaults
#   (seed 1337, temperature 0.8, top-k 200). From it, the share of generated words
#   that occur in the training text ("valid-word rate").
#
# Results are cached in `runs/<name>/eval.json`.

# %%
def load_model(run_dir):
    ckpt = torch.load(os.path.join(run_dir, "ckpt.pt"), map_location=device, weights_only=False)
    with contextlib.redirect_stdout(io.StringIO()):          # silence "number of parameters"
        model = GPT(GPTConfig(**ckpt["model_args"]))
    model.load_state_dict(ckpt["model"])
    return model.to(device).eval()


@torch.no_grad()
def window_losses(model, ids, starts, T):
    out = []
    for i in range(0, len(starts), 256):
        s = starts[i:i + 256]
        x = torch.from_numpy(np.stack([ids[j:j + T] for j in s]).astype(np.int64)).to(device)
        y = torch.from_numpy(np.stack([ids[j + 1:j + 1 + T] for j in s]).astype(np.int64)).to(device)
        logits = model.lm_head(model_body(model, x))
        out.append(F.cross_entropy(logits.reshape(-1, VOCAB), y.reshape(-1), reduction="none").view(len(s), T))
    return torch.cat(out).cpu().numpy()


def model_body(model, idx):
    """GPT.forward without the lm_head shortcut, so logits exist at every position."""
    t = idx.size(1)
    pos = torch.arange(0, t, dtype=torch.long, device=idx.device)
    x = model.transformer.drop(model.transformer.wte(idx) + model.transformer.wpe(pos))
    for block in model.transformer.h:
        x = block(x)
    return model.transformer.ln_f(x)


def valid_word_rate(text):
    words = re.findall(r"[a-z']+", text.lower())
    return float(np.mean([w in TRAIN_WORDS for w in words])) if words else float("nan")


def evaluate(run_dir, T):
    path = os.path.join(run_dir, "eval.json")
    if os.path.exists(path):
        res = json.load(open(path))
        if "val_by_pos_dense" not in res:
            res["val_by_pos_dense"] = position_profile(load_model(run_dir), T)
            json.dump(res, open(path, "w"), indent=1)
        return res
    model = load_model(run_dir)
    val_starts = np.arange(0, len(val_ids) - T - 1, T)
    rng = np.random.default_rng(0)
    train_starts = rng.integers(0, len(train_ids) - T - 1, size=len(val_starts))
    lv = window_losses(model, val_ids, val_starts, T)
    lt = window_losses(model, train_ids, train_starts, T)
    torch.manual_seed(1337)
    torch.cuda.manual_seed(1337)
    x = torch.tensor([[stoi["\n"]]], device=device)
    y = model.generate(x, 500, temperature=0.8, top_k=200)
    sample = "".join(itos[int(i)] for i in y[0].tolist()[1:])
    res = {"val_loss": float(lv.mean()), "train_loss": float(lt.mean()),
           "val_by_pos": lv.mean(0).tolist(), "val_tokens": int(lv.size),
           "val_by_pos_dense": position_profile(model, T),
           "sample": sample, "valid_word_rate": valid_word_rate(sample)}
    json.dump(res, open(path, "w"), indent=1)
    return res


def position_profile(model, T):
    """Validation loss by window position, from windows starting every T/8 characters.

    Non-overlapping windows put each character at one fixed position, so the
    per-position mean is dominated by which characters happen to land there.
    Eight staggered offsets average that out."""
    starts = np.arange(0, len(val_ids) - T - 1, T // 8)
    return window_losses(model, val_ids, starts, T).mean(0).tolist()


t0 = time.time()
evals = {}
for name, T in zip(runs.name, runs.block_size):
    evals[name] = evaluate(os.path.join(grid.RUNS, name), int(T))
print(f"evaluated {len(evals)} models in {time.time() - t0:.0f}s")
for k in ["val_loss", "train_loss", "valid_word_rate"]:
    runs[k] = [evals[n][k] for n in runs.name]
runs["gap"] = runs.val_loss - runs.train_loss
runs["slice"] = list(zip(runs.block_size, runs.n_layer))
runs["is_repeat"] = runs.seed != grid.BASE_SEED
main = runs[~runs.is_repeat].copy()
print("exact val loss: best", main.val_loss.min().round(4), "worst", main.val_loss.max().round(4))
print("correlation of exact val loss with train.py's last estimate:",
      np.corrcoef(main.val_loss, main.log_final_val)[0, 1].round(3))

# %% [markdown]
# ## 5. Run-to-run noise (seed repeats)
#
# Four configs were trained with seeds 1337, 1338 and 1339. Their spread is the
# yardstick for every comparison below. The pooled standard deviation σ of one
# run's validation loss gives a standard error for each factorial effect of
# 2σ/√128, because every main effect is a difference of two means over 64 runs.

# %%
rep_rows = []
for cfg in grid.REPEAT_CONFIGS:
    names = [grid.run_name(cfg, s) for s in [grid.BASE_SEED] + grid.REPEAT_SEEDS]
    sub = runs.set_index("name").loc[names]
    rep_rows.append({"config": grid.run_name(cfg), "val_losses": sub.val_loss.round(4).tolist(),
                     "val_sd": sub.val_loss.std(ddof=1), "gap_sd": sub.gap.std(ddof=1),
                     "time_sd": sub.train_time_s.std(ddof=1), "time_mean": sub.train_time_s.mean()})
rep = pd.DataFrame(rep_rows)
SIGMA = float(np.sqrt((rep.val_sd ** 2).mean()))
SIGMA_GAP = float(np.sqrt((rep.gap_sd ** 2).mean()))
SE_EFFECT = 2 * SIGMA / np.sqrt(len(main))
print(f"pooled seed sd of val loss: {SIGMA:.4f}; of the gap: {SIGMA_GAP:.4f}; "
      f"SE of a main effect: {SE_EFFECT:.4f}")
RESULTS["noise"] = {"repeats": rep_rows, "sigma_val": SIGMA, "sigma_gap": SIGMA_GAP, "se_effect": SE_EFFECT}
rep

# %% [markdown]
# **Wall-clock incident and same-seed reruns.** In the first pass, the first ~30
# runs (all from our slice [128, 6]) ran 3-7x slower than identical work later
# on, because a GPU-heavy video game was running on the same machine. For example,
# `b128_l6_h4_e128_bs16_it2000_d0.1` took 58.6 s, while its two seed repeats took
# 19.8 s. Losses do not depend on speed, but timing is a tracked metric, so all
# 32 runs of our slice were rerun with the same seeds on a quiet machine. The
# first-pass logs are kept in `runs_slow_archive/`. The comparison below doubles
# as a reproducibility check: same config, same seed, run twice.

# %%
arch_rows = []
for name in sorted(os.listdir(os.path.join(ROOT, "runs_slow_archive"))):
    old = json.load(open(os.path.join(ROOT, "runs_slow_archive", name, "summary.json")))
    old_ev, _ = parse_log(os.path.join(ROOT, "runs_slow_archive", name, "train.log"))
    new = runs.set_index("name").loc[name]
    arch_rows.append({"name": name, "first_pass_s": old["train_time_s"], "rerun_s": new.train_time_s,
                      "first_pass_final_val_est": float(old_ev.val.iloc[-1]), "rerun_final_val_est": new.log_final_val})
arch = pd.DataFrame(arch_rows)
arch["slowdown"] = arch.first_pass_s / arch.rerun_s
arch["val_diff"] = (arch.first_pass_final_val_est - arch.rerun_final_val_est).abs()
RESULTS["rerun"] = {"n": len(arch), "max_val_diff": float(arch.val_diff.max()),
                    "median_val_diff": float(arch.val_diff.median()),
                    "slowdown_median": float(arch.slowdown.median()), "slowdown_max": float(arch.slowdown.max()),
                    "slowdown_min": float(arch.slowdown.min())}
print(RESULTS["rerun"])
arch.round(3).head(8)

# %% [markdown]
# ## 6. Results table and the best runs

# %%
cols = ["name", "n_params", "tokens_seen", "train_time_s", "median_step_ms", "peak_mem_mb",
        "train_loss", "val_loss", "gap", "valid_word_rate"]
best = main.sort_values("val_loss")
print("10 best runs by exact validation loss:")
print(best[cols].head(10).round(4).to_string(index=False))
print("\n5 worst runs:")
print(best[cols].tail(5).round(4).to_string(index=False))
slice_best = main.loc[main.groupby("slice").val_loss.idxmin()]
print("\nbest run per member slice:")
print(slice_best[["slice"] + cols].round(4).to_string(index=False))
main[cols + FACTORS].to_csv(os.path.join(ROOT, "results.csv"), index=False)
RESULTS["best"] = best[cols].head(10).to_dict("records")
RESULTS["worst"] = best[cols].tail(5).to_dict("records")
RESULTS["slice_best"] = slice_best[cols].to_dict("records")
RESULTS["slice_summary"] = (main.groupby("slice")
                            .agg(best_val=("val_loss", "min"), median_val=("val_loss", "median"),
                                 worst_val=("val_loss", "max"), median_time=("train_time_s", "median"),
                                 total_time=("train_time_s", "sum"))
                            .reset_index().assign(slice=lambda d: d.slice.astype(str)).to_dict("records"))

# %% [markdown]
# ## 7. Which hyperparameters matter? Factorial main effects and interactions
#
# The grid is a full 2^7 factorial, so each factor's **main effect** is exact:
# the mean outcome at its high level minus the mean at its low level, averaged
# over all 64 combinations of the other six factors. Two-factor interactions use
# the product of the two ±1 codes. Effects are compared with the seed-noise
# standard error from section 5.

# %%
codes = pd.DataFrame({f: np.where(main[f] == grid.FACTORS[f][1], 1.0, -1.0) for f in FACTORS}, index=main.index)


def effects(y):
    y = np.asarray(y, float)
    out = {}
    for f in FACTORS:
        out[f] = y[codes[f] > 0].mean() - y[codes[f] < 0].mean()
    return out


def interactions(y):
    y = np.asarray(y, float)
    m = pd.DataFrame(np.nan, index=FACTORS, columns=FACTORS)
    for i, a in enumerate(FACTORS):
        for b in FACTORS[i + 1:]:
            s = codes[a] * codes[b]
            m.loc[a, b] = m.loc[b, a] = y[s > 0].mean() - y[s < 0].mean()
    return m


outcomes = {"val_loss": main.val_loss, "gap": main.gap, "train_time_s": main.train_time_s,
            "peak_mem_mb": main.peak_mem_mb, "n_params": main.n_params,
            "valid_word_rate": main.valid_word_rate}
eff = pd.DataFrame({k: effects(v) for k, v in outcomes.items()})
inter = interactions(main.val_loss)
low_means = {f: main[codes[f] < 0].val_loss.mean() for f in FACTORS}
eff["val_loss_low_mean"] = pd.Series(low_means)
eff["val_effect_in_SE"] = eff.val_loss / SE_EFFECT
RESULTS["effects"] = eff.reset_index().rename(columns={"index": "factor"}).to_dict("records")
iu = [(a, b, inter.loc[a, b]) for i, a in enumerate(FACTORS) for b in FACTORS[i + 1:]]
iu = sorted(iu, key=lambda t: -abs(t[2]))
RESULTS["top_interactions"] = [{"a": a, "b": b, "effect": float(v), "in_SE": float(v / SE_EFFECT)} for a, b, v in iu[:8]]
print("main effects (high level minus low level):")
print(eff.round(4).to_string())
print("\nlargest two-factor interactions on val loss:")
for a, b, v in iu[:8]:
    print(f"  {a:10s} x {b:10s} {v:+.4f}  ({v / SE_EFFECT:+.1f} SE)")

# %%
fig, axes = plt.subplots(1, 4, figsize=(13, 3.4), sharey=True)
order = list(eff.val_loss.sort_values().index)
ylab = [f"{SHORT[f]} {grid.FACTORS[f][0]}→{grid.FACTORS[f][1]}" for f in order]
panels = [("val_loss", "Δ validation loss", "{:+.3f}"), ("gap", "Δ train-val gap", "{:+.3f}"),
          ("train_time_s", "Δ training time (s)", "{:+.1f}"), ("peak_mem_mb", "Δ peak GPU memory (MB)", "{:+.0f}")]
for ax, (col, title, fmt) in zip(axes, panels):
    vals = eff.loc[order, col].values
    colors = [BLUE if v < 0 else ORANGE for v in vals] if col in ("val_loss", "gap") else [MUTED] * len(vals)
    ax.barh(range(len(order)), vals, color=colors, height=0.62)
    span = np.abs(vals).max()
    for k, v in enumerate(vals):
        ax.text(v + (0.03 * span if v >= 0 else -0.03 * span), k, fmt.format(v), va="center",
                ha="left" if v >= 0 else "right", fontsize=8, color=INK)
    ax.axvline(0, color=INK, lw=0.8)
    if col == "val_loss":
        ax.axvspan(-2 * SE_EFFECT, 2 * SE_EFFECT, color=LIGHT, zorder=0)
        ax.set_xlabel(f"gray band: ±2 SE of seed noise (±{2 * SE_EFFECT:.3f})", fontsize=8)
    elif col == "gap":
        se_gap = 2 * SIGMA_GAP / np.sqrt(len(main))
        ax.axvspan(-2 * se_gap, 2 * se_gap, color=LIGHT, zorder=0)
    ax.set_xlim(-span * 1.45 if vals.min() < 0 else -span * 0.1, span * 1.45 if vals.max() > 0 else span * 0.1)
    ax.set_title(title, fontsize=10)
axes[0].set_yticks(range(len(order)), ylab)
axes[0].invert_yaxis()
fig.suptitle("Main effects over the 128-run grid: mean at the high level minus mean at the low level "
             "(blue = lower loss / smaller gap)", fontsize=10)
fig.tight_layout()
show(fig, "fig_main_effects.png")

fig, ax = plt.subplots(figsize=(5.6, 4.4))
m = inter.loc[FACTORS, FACTORS].values.astype(float)
lim = np.nanmax(np.abs(m))
im = ax.imshow(m, cmap="RdBu_r", vmin=-lim, vmax=lim)
for i in range(len(FACTORS)):
    for j in range(len(FACTORS)):
        if i != j:
            ax.text(j, i, f"{m[i, j]:+.3f}", ha="center", va="center", fontsize=7.5,
                    color="white" if abs(m[i, j]) > 0.6 * lim else INK)
ax.set_xticks(range(len(FACTORS)), [SHORT[f] for f in FACTORS], rotation=30)
ax.set_yticks(range(len(FACTORS)), [SHORT[f] for f in FACTORS])
ax.grid(False)
ax.set_title(f"Two-factor interactions on validation loss\n(SE of one cell = {SE_EFFECT:.4f})", fontsize=10)
fig.colorbar(im, ax=ax, fraction=0.046, label="interaction effect")
show(fig, "fig_interactions.png")

# %% [markdown]
# ## 8. Loss curves

# %%
fig, axes = plt.subplots(1, 4, figsize=(13, 3.4), sharey=True)
for ax, sl in zip(axes, [(64, 4), (64, 6), (128, 4), (128, 6)]):
    sub = main[main.slice == sl]
    b, w = sub.loc[sub.val_loss.idxmin()], sub.loc[sub.val_loss.idxmax()]
    for name in sub.name:
        ev = curves[name]
        ax.plot(ev.step, ev.val, color=LIGHT, lw=0.9)
    for r, color, lab in [(b, BLUE, "best"), (w, ORANGE, "worst")]:
        ev = curves[r["name"]]
        ax.plot(ev.step, ev.val, color=color, lw=1.8, label=f"{lab}: {r['val_loss']:.3f}")
        ax.plot(ev.step, ev.train, color=color, lw=1.0, ls="--")
    ax.set_title(SLICE_LABEL[sl], fontsize=10)
    ax.set_xlabel("iteration")
    ax.set_ylim(1.3, 3.4)
    ax.legend(frameon=False, fontsize=8, title="val (solid), train (dashed)", title_fontsize=7.5)
axes[0].set_ylabel("loss (train.py estimate)")
fig.suptitle("Validation loss curves of all 32 runs per slice (gray), best and worst highlighted", fontsize=10)
fig.tight_layout()
show(fig, "fig_curves_by_slice.png")

# Mean validation curve at each level of each factor (curves average over the other factors).
fig, axes = plt.subplots(2, 4, figsize=(11, 5.2), sharey=True)
axes = axes.ravel()
axes[-1].axis("off")
for ax, f in zip(axes, FACTORS):
    for lvl, color in zip(grid.FACTORS[f], [BLUE, ORANGE]):
        names = main[main[f] == lvl].name
        cv = pd.concat([curves[n].set_index("step").val for n in names], axis=1)
        if f == "max_iters":
            mean = cv.mean(axis=1).dropna()
        else:
            mean = cv.loc[:1000].mean(axis=1)              # common range for all runs
        ax.plot(mean.index, mean.values, color=color, label=f"{lvl}")
    ax.set_title(SHORT[f], fontsize=10)
    ax.set_xlabel("iteration")
    ax.set_ylim(1.4, 2.8)
    ax.legend(frameon=False, fontsize=8)
axes[0].set_ylabel("mean val loss")
axes[4].set_ylabel("mean val loss")
fig.suptitle("Mean validation curve at each level of each factor (iterations 0-1000 except for max_iters)",
             fontsize=10)
fig.tight_layout()
show(fig, "fig_curves_by_factor.png")

# %% [markdown]
# ## 9. Cost: time, memory, parameters, tokens

# %%
fig, axes = plt.subplots(1, 3, figsize=(13, 3.6))
for ax, (x, xlab, logx) in zip(axes, [("train_time_s", "training wall-clock (s, log scale)", True),
                                      ("tokens_seen", "training tokens processed (log scale)", True),
                                      ("n_params", "parameters (log scale)", True)]):
    for lvl, color in zip([128, 256], [BLUE, ORANGE]):
        sub = main[main.n_embd == lvl]
        ax.scatter(sub[x], sub.val_loss, s=16, color=color, alpha=0.85, label=f"n_embd {lvl}",
                   edgecolors="white", linewidths=0.4)
    if x == "train_time_s":
        srt = main.sort_values(x)
        frontier = srt[srt.val_loss <= srt.val_loss.cummin()]
        ax.step(frontier[x], frontier.val_loss, where="post", color=INK, lw=1, label="best so far")
    if logx:
        ax.set_xscale("log")
        ticks = {"train_time_s": [7, 10, 15, 20], "tokens_seen": [0.5e6, 1e6, 2e6, 4e6],
                 "n_params": [0.8e6, 1.2e6, 3.2e6, 4.8e6]}[x]
        fmt = (lambda v: f"{v:g}") if x == "train_time_s" else (lambda v: f"{v / 1e6:g}M")
        ax.set_xticks(ticks, [fmt(v) for v in ticks])
        ax.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
    ax.set_xlabel(xlab)
    ax.legend(frameon=False, fontsize=8)
axes[0].set_ylabel("exact validation loss")
axes[0].set_title("Accuracy vs compute time", fontsize=10)
axes[1].set_title("Accuracy vs data seen (batch × block × iters)", fontsize=10)
axes[2].set_title("Accuracy vs model size", fontsize=10)
fig.tight_layout()
show(fig, "fig_cost.png")

param_tab = (main.groupby(["n_layer", "n_embd", "block_size"])
             .agg(params=("n_params", "first"), peak_mem_mb_bs8=("peak_mem_mb", lambda s: s[main.loc[s.index, "batch_size"] == 8].mean()),
                  peak_mem_mb_bs16=("peak_mem_mb", lambda s: s[main.loc[s.index, "batch_size"] == 16].mean()),
                  median_step_ms=("median_step_ms", "median"))
             .reset_index())
RESULTS["params_memory"] = param_tab.to_dict("records")
print(param_tab.round(1).to_string(index=False))
print("\ntotal training wall-clock for the 128 grid runs: %.1f min" % (main.train_time_s.sum() / 60))
RESULTS["total_train_min"] = float(main.train_time_s.sum() / 60)
RESULTS["time_vs_est_step"] = float(np.corrcoef(main.train_time_s, main.est_step_time_s)[0, 1])

# %% [markdown]
# ## 10. Overfitting: the train/validation gap

# %%
fig, axes = plt.subplots(1, 2, figsize=(11, 3.8))
ax = axes[0]
for lvl, color in zip([0.1, 0.2], [ORANGE, BLUE]):
    sub = main[main.dropout == lvl]
    ax.scatter(sub.train_loss, sub.val_loss, s=16, color=color, label=f"dropout {lvl}",
               edgecolors="white", linewidths=0.4)
lo, hi = main[["train_loss", "val_loss"]].min().min() - 0.02, main[["train_loss", "val_loss"]].max().max() + 0.02
ax.plot([lo, hi], [lo, hi], color=MUTED, ls="--", lw=1)
ax.text(lo + 0.12, lo + 0.06, "val = train", ha="left", fontsize=8, color=MUTED, rotation=33)
ax.set_xlabel("exact train loss (fixed sample)")
ax.set_ylabel("exact validation loss")
ax.set_title("Final train vs validation loss", fontsize=10)
ax.legend(frameon=False)

ax = axes[1]
grp = main.groupby(["n_embd", "n_layer", "max_iters", "dropout"]).gap.mean().unstack("dropout")
labels = [f"e{e} l{l} it{it}" for e, l, it in grp.index]
x = np.arange(len(grp))
ax.bar(x - 0.2, grp[0.1], width=0.38, color=ORANGE, label="dropout 0.1")
ax.bar(x + 0.2, grp[0.2], width=0.38, color=BLUE, label="dropout 0.2")
ax.axhline(0, color=INK, lw=0.8)
ax.set_xticks(x, labels, rotation=45, ha="right", fontsize=8)
ax.set_ylabel("mean gap (val − train)")
ax.set_title("Gap by size, training length and dropout", fontsize=10)
ax.legend(frameon=False)
fig.tight_layout()
show(fig, "fig_overfitting.png")
RESULTS["gap_stats"] = {"max_gap": float(main.gap.max()), "min_gap": float(main.gap.min()),
                        "median_gap": float(main.gap.median()),
                        "max_gap_run": main.loc[main.gap.idxmax(), "name"],
                        "val_rising_runs": int((main.log_best_val < main.log_final_val - 0.01).sum()),
                        "val_rising_names": main[main.log_best_val < main.log_final_val - 0.01].name.tolist(),
                        "gap_by_dropout": main.groupby("dropout").gap.mean().to_dict(),
                        "val_by_dropout": main.groupby("dropout").val_loss.mean().to_dict(),
                        "dropout_gap_strong": main[strong_mask := ((main.n_embd == 256) & (main.max_iters == 2000)
                                                                   & (main.batch_size == 16))]
                        .groupby("dropout").gap.mean().to_dict(),
                        "dropout_val_strong": main[strong_mask].groupby("dropout").val_loss.mean().to_dict()}
print(RESULTS["gap_stats"])

# %% [markdown]
# ## 11. Context length and fair (equal-token) comparisons
#
# The validation loss at window position p is predicted from p+1 characters of
# context, so its curve over p shows how much extra context each model actually
# uses ("long-range dependencies"). The curves average windows starting every T/8
# characters.
#
# block_size has a confound. A 128-block batch carries twice the tokens of a
# 64-block batch, so the plain block_size effect mixes **longer context** with
# **more training data**. The grid contains pairs that process the same number
# of tokens, which isolates the trade-offs:
#
# * context vs batch: (block 128, batch 8) vs (block 64, batch 16), with the same iterations;
# * context vs steps: (block 128, 1000 iters) vs (block 64, 2000 iters), with the same batch;
# * batch vs steps: (batch 16, 1000 iters) vs (batch 8, 2000 iters), with the same block.
#
# Each comparison has 32 pairs, matched on the remaining five factors.

# %%
pos = {}
strong = (main.n_embd == 256) & (main.max_iters == 2000) & (main.batch_size == 16)
for T in [64, 128]:
    pos[T] = np.mean([evals[n]["val_by_pos_dense"] for n in main[main.block_size == T].name], axis=0)
    pos[(T, "strong")] = np.mean([evals[n]["val_by_pos_dense"]
                                  for n in main[(main.block_size == T) & strong].name], axis=0)


def ctx_gain(p, a, b):
    """Mean loss at positions a..b (1-based context lengths)."""
    return float(np.mean(p[a - 1:b]))


pair = main.pivot_table(index=["n_layer", "n_head", "n_embd", "batch_size", "max_iters", "dropout"],
                        columns="block_size", values="val_loss")
pair_diff = (pair[128] - pair[64])

others = ["n_layer", "n_head", "n_embd", "dropout"]


def equal_token(a_mask, b_mask, keys, label_a, label_b):
    A = main[a_mask].set_index(keys).val_loss.sort_index()
    B = main[b_mask].set_index(keys).val_loss.sort_index()
    d = (A - B).dropna()
    return {"a": label_a, "b": label_b, "pairs": int(len(d)), "mean_diff": float(d.mean()),
            "a_better": int((d < 0).sum()), "min": float(d.min()), "max": float(d.max())}


fair = [
    equal_token((main.block_size == 128) & (main.batch_size == 8), (main.block_size == 64) & (main.batch_size == 16),
                others + ["max_iters"], "block 128, batch 8", "block 64, batch 16"),
    equal_token((main.block_size == 128) & (main.max_iters == 1000), (main.block_size == 64) & (main.max_iters == 2000),
                others + ["batch_size"], "block 128, 1000 iters", "block 64, 2000 iters"),
    equal_token((main.batch_size == 16) & (main.max_iters == 1000), (main.batch_size == 8) & (main.max_iters == 2000),
                others + ["block_size"], "batch 16, 1000 iters", "batch 8, 2000 iters"),
]
RESULTS["context"] = {
    "loss_ctx_1": [float(pos[64][0]), float(pos[128][0])],
    "all_64": {"c4_8": ctx_gain(pos[64], 4, 8), "c56_64": ctx_gain(pos[64], 56, 64)},
    "all_128": {"c4_8": ctx_gain(pos[128], 4, 8), "c56_64": ctx_gain(pos[128], 56, 64),
                "c120_128": ctx_gain(pos[128], 120, 128)},
    "strong_64": {"c4_8": ctx_gain(pos[(64, "strong")], 4, 8), "c56_64": ctx_gain(pos[(64, "strong")], 56, 64)},
    "strong_128": {"c4_8": ctx_gain(pos[(128, "strong")], 4, 8), "c56_64": ctx_gain(pos[(128, "strong")], 56, 64),
                   "c120_128": ctx_gain(pos[(128, "strong")], 120, 128)},
    "paired_diff_mean": float(pair_diff.mean()), "paired_diff_min": float(pair_diff.min()),
    "paired_diff_max": float(pair_diff.max()), "paired_128_better": int((pair_diff < 0).sum()),
    "equal_token": fair,
}
print(json.dumps(RESULTS["context"], indent=1))

fig, axes = plt.subplots(1, 2, figsize=(11, 3.5), gridspec_kw={"width_ratios": [1.5, 1]})
ax = axes[0]
x64, x128 = np.arange(1, 65), np.arange(1, 129)
ax.plot(x64, pos[64], color=BLUE, lw=1.2, alpha=0.55, label="block 64, all 64 runs")
ax.plot(x128, pos[128], color=ORANGE, lw=1.2, alpha=0.55, label="block 128, all 64 runs")
ax.plot(x64, pos[(64, "strong")], color=BLUE, lw=2, label="block 64, strongest 8 (embd 256, batch 16, 2000 it)")
ax.plot(x128, pos[(128, "strong")], color=ORANGE, lw=2, label="block 128, strongest 8")
ax.set_xscale("log", base=2)
ax.set_xticks([1, 2, 4, 8, 16, 32, 64, 128], [1, 2, 4, 8, 16, 32, 64, 128])
ax.set_xlabel("characters of context (position in window + 1)")
ax.set_ylabel("validation loss at that position")
ax.set_title("Loss by available context", fontsize=10)
ax.legend(frameon=False, fontsize=7.5)
ax = axes[1]
labels = [f"{f['a']}\nvs {f['b']}" for f in fair]
vals = [f["mean_diff"] for f in fair]
ax.barh(range(len(fair)), vals, color=[BLUE if v < 0 else ORANGE for v in vals], height=0.55)
for k, f in enumerate(fair):
    v = f["mean_diff"]
    ax.text(v + (0.002 if v >= 0 else -0.002), k, f"{v:+.3f}  ({f['a_better']}/{f['pairs']})",
            va="center", ha="left" if v >= 0 else "right", fontsize=8)
ax.axvline(0, color=INK, lw=0.8)
ax.set_yticks(range(len(fair)), labels, fontsize=8)
ax.invert_yaxis()
span = max(abs(v) for v in vals)
ax.set_xlim(-span * 2.2, span * 2.2)
ax.set_xlabel("mean val-loss difference, first minus second\n(negative = first is better; wins in parentheses)")
ax.set_title("Equal-token comparisons (32 matched pairs each)", fontsize=10)
fig.tight_layout()
show(fig, "fig_context.png")

# %% [markdown]
# ## 12. Generated text

# %%
fig, ax = plt.subplots(figsize=(5.6, 3.4))
for is_ours, color, label in [(False, LIGHT, "other three slices"), (True, BLUE, SLICE_LABEL[OUR_SLICE])]:
    sub = main[(main.slice == OUR_SLICE) == is_ours]
    ax.scatter(sub.val_loss, sub.valid_word_rate, s=18, color=color, label=label,
               edgecolors=MUTED if not is_ours else "white", linewidths=0.4)
ax.set_xlabel("exact validation loss")
ax.set_ylabel("valid-word rate of a 500-char sample")
ax.set_title("Sample quality tracks validation loss", fontsize=10)
ax.legend(frameon=False, fontsize=7.5)
show(fig, "fig_samples.png")
RESULTS["word_rate_corr"] = float(np.corrcoef(main.val_loss, main.valid_word_rate)[0, 1])
print("corr(val loss, valid-word rate) =", round(RESULTS["word_rate_corr"], 3))

best_ours = slice_best[slice_best.slice == OUR_SLICE].iloc[0]["name"]
sample_runs = {("best overall (our slice)" if best_ours == best.iloc[0]["name"] else "best overall"): best.iloc[0]["name"]}
if best_ours != best.iloc[0]["name"]:
    sample_runs["best in our slice [128, 6]"] = best_ours
sample_runs["best with block_size 64"] = main[main.block_size == 64].sort_values("val_loss").iloc[0]["name"]
sample_runs["median run"] = best.iloc[len(best) // 2]["name"]
sample_runs["worst overall"] = best.iloc[-1]["name"]
RESULTS["samples"] = {}
for label, name in sample_runs.items():
    e = evals[name]
    RESULTS["samples"][label] = {"name": name, "val_loss": e["val_loss"],
                                 "valid_word_rate": e["valid_word_rate"], "text": e["sample"][:400]}
    print(f"=== {label}: {name}  (val {e['val_loss']:.3f}, valid words {e['valid_word_rate']:.0%})")
    print(e["sample"][:400])
    print()

# %% [markdown]
# ## 13. Per-slice result tables and saved results

# %%
slice_tables = {}
for sl in [(64, 4), (64, 6), (128, 4), (128, 6)]:
    t = (main[main.slice == sl]
         .sort_values(["n_head", "n_embd", "batch_size", "max_iters", "dropout"])
         [["n_head", "n_embd", "batch_size", "max_iters", "dropout", "n_params", "train_time_s",
           "peak_mem_mb", "train_loss", "val_loss", "gap", "valid_word_rate"]])
    slice_tables[str(sl)] = t.to_dict("records")
RESULTS["slice_tables"] = slice_tables
RESULTS["n_runs"] = int(len(runs))
RESULTS["hardware"] = {"gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else "cpu",
                       "torch": torch.__version__}


def clean(o):
    if isinstance(o, dict):
        return {str(k): clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [clean(v) for v in o]
    if isinstance(o, np.integer):
        return int(o)
    if isinstance(o, (np.floating, float)):
        return None if not np.isfinite(o) else float(o)
    return o


json.dump(clean(RESULTS), open(os.path.join(ROOT, "results.json"), "w"), indent=1)
print("saved results.json and results.csv")
